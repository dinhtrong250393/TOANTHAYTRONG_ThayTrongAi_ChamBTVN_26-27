# Phương Án Triển Khai: Tính Năng Tạo & Chấm Đề Trắc Nghiệm Tùy Chỉnh Điểm (Custom Quiz & Custom Barem)

Phương án chi tiết xây dựng tính năng tạo, giao bài và tự động chấm điểm cho **Đề thi Trắc nghiệm Tùy chỉnh (Custom Quiz)**. Tính năng cho phép Giáo viên tự do thiết lập điểm số mặc định theo từng loại câu (Trắc nghiệm 4 lựa chọn, Đúng/Sai từng ý a/b/c/d, Trả lời ngắn) HOẶC đè điểm lẻ cho từng câu hỏi cá nhân, đồng thời giữ nguyên toàn bộ cơ chế chấm tự động đa luồng và báo cáo kết quả hiện có của hệ thống.

---

## User Review & Critical Decisions

> [!IMPORTANT] Các quyết định cốt lõi đã thống nhất cùng Giáo viên:

- **Confirmed Decision 1 (Cách cấu hình điểm)**: Hệ thống hỗ trợ song song cả 2 cách: Đặt **điểm mặc định theo loại câu** (Trắc nghiệm, Đúng/Sai, Trả lời ngắn) VÀ cho phép **chỉnh sửa điểm lẻ trực tiếp trên từng câu hỏi cá nhân**.
- **Confirmed Decision 2 (Phân loại & Quản lý đề thi)**: Tạo Tab menu riêng **"Barem tùy chọn / Đề tùy chỉnh"** trên Bảng điều khiển Giáo viên bên cạnh Tab "Đề chuẩn THPT" để tách biệt hai hình thức thi.
- **Confirmed Decision 3 (Quy đổi điểm & Chấm điểm)**: Mặc định quy đổi tổng điểm bài làm về **thang điểm 10 chuẩn** để đồng bộ với học bạ và biểu đồ phân bố điểm, đồng thời hiển thị kèm tổng điểm thực tế (VD: `8.5 / 10 (Thực tế: 17/20 điểm)`).

---

## 1. Overview & Core Concept

### Mục Tiêu
Cung cấp giải pháp linh hoạt cho Giáo viên khi tạo các đề kiểm tra 15 phút, 1 tiết, đề thi học kỳ hoặc đề luyện tập theo ma trận điểm riêng (không bị gò bó bởi cấu trúc cố định 12 câu TN + 4 câu Đ/S + 6 câu TLN của bộ GD&ĐT).

### Bối Cảnh Người Dùng
- **Giáo viên**: Tạo đề nhanh từ file PDF/Word/Ảnh bằng AI, cấu hình thang điểm mong muốn (VD: 0.5 điểm/câu trắc nghiệm, 1.0 điểm/câu trả lời ngắn), giao cho lớp và xem báo cáo kết quả tức thì.
- **Học sinh**: Làm bài trực tuyến trên giao diện tối ưu, xem kết quả chấm tự động chi tiết từng câu sai và lời giải ngay sau khi nộp.

---

## 2. User Experience & Visual Design

### UX Flow
```
┌─────────────────────────┐      ┌──────────────────────────┐      ┌──────────────────────────┐
│  Bảng Điều Khiển (GV)   │ ───► │  Trình Tạo Đề Tùy Chỉnh  │ ───► │ Cấu Hình Điểm & AI Parse │
│ (Tab Barem Tùy Chỉnh)   │      │   (Custom Quiz Builder)  │      │  (Loại câu & Điểm lẻ)    │
└─────────────────────────┘      └──────────────────────────┘      └──────────────────────────┘
                                                                                 │
                                                                                 ▼
┌─────────────────────────┐      ┌──────────────────────────┐      ┌──────────────────────────┐
│ Báo Cáo & Chấm Song Song│ ◄─── │ Học Sinh Làm Bài & Nộp   │ ◄─── │  Giao Bài Cho Các Lớp    │
│  (Bảng điểm & Biểu đồ) │      │ (Tự động chấm theo Barem)│      │   (Đặt thời gian mờ)    │
└─────────────────────────┘      └──────────────────────────┘      └──────────────────────────┘
```

### Visual Identity & Theme Alignment
- **Phong cách**: B2B EdTech Dashboard hiện đại, sạch sẽ, chuẩn **Anti-Slop Discipline** (không dùng nút bo tròn viên thuốc giả, không icon trang trí thừa, không thẻ bọc màu sặc sỡ).
- **Phân màu nhận diện**:
  - *Đề chuẩn THPT*: Nhãn Indigo/Blue (`#4F46E5`).
  - *Đề Barem Tùy chỉnh*: Nhãn Purple/Violet (`#7C3AED`) để phân biệt trực quan tức thì.
- **Trình bày Typography**: Sử dụng phông chữ Inter chuyên nghiệp, hệ số chữ số dạng bảng (`tabular-nums`) cho bảng điểm và KaTeX hiển thị công thức toán học sắc nét.

---

## 3. Key Product Decisions & Trade-Offs

### Decision 1: Cấu trúc Lưu trữ Điểm số trên từng Câu hỏi (`Question` Entity)
- **Phương án chọn**: Thêm trường `point?: number` vào đối tượng `Question` và đối tượng `customScoring` trong `Exam` document.
- **Lý do**:
  - Nếu câu hỏi có `q.point` riêng -> Sử dụng `q.point`.
  - Nếu câu hỏi không khai báo `q.point` -> Tự động dùng điểm từ `customScoring[q.type]`.
  - Giúp tương thích ngược 100% với các đề thi cũ mà không làm vỡ dữ liệu Firestore hiện tại.

### Decision 2: Thuật Toán Chấm Điểm Tự Động (Auto-Grading Algorithm)
- **Phương án chọn**:
  - Với câu Trắc nghiệm 4 lựa chọn: Ăn đủ `point` nếu chọn đúng.
  - Với câu Đúng/Sai (4 ý a, b, c, d): Mỗi ý đúng được `point / 4` (hoặc tính tỷ lệ theo cấu hình 1/2/3/4 ý đúng).
  - Với câu Trả lời ngắn: Ăn đủ `point` nếu chuỗi đáp án trùng khớp (sau khi `trim()` và viết thường).
  - **Công thức quy đổi**:
    $$\text{Điểm quy đổi (Thang 10)} = \min\left(10, \frac{\text{Tổng điểm đạt được}}{\text{Tổng điểm tối đa của đề}} \times 10\right)$$
- **Lý do**: Đảm bảo điểm số luôn khách quan, nhất quán và hiển thị trực quan cả điểm thực tế lẫn điểm quy đổi thang 10.

---

## 4. Technical Architecture & Data Strategy

### System Architecture Diagram

```
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                   FRONTEND (React SPA)                                 │
│                                                                                        │
│  ┌──────────────────────┐   ┌──────────────────────┐   ┌────────────────────────────┐  │
│  │ TeacherDashboard.tsx │   │  ExamBuilder.tsx     │   │ TakeExam.tsx               │  │
│  │ (Tab Custom Quizzes) │   │ (isCustomQuizMode)   │   │ (Renders Custom Barem)     │  │
│  └──────────┬───────────┘   └──────────┬───────────┘   └─────────────┬──────────────┘  │
└─────────────│──────────────────────────│─────────────────────────────│─────────────────┘
              │                          │                             │
              ▼                          ▼                             ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                   EXPRESS SERVER (Node.js)                             │
│                                                                                        │
│  ┌─────────────────────────────────┐       ┌────────────────────────────────────────┐  │
│  │  POST /api/solve-textbook-...   │       │  POST /api/batch-grade/start           │  │
│  │  (AI Parse PDF/Word -> Questions)│       │  (Gemini 3.8 Flash Parallel Workers)   │  │
│  └─────────────────────────────────┘       └────────────────────────────────────────┘  │
└────────────────────────────────────────┬───────────────────────────────────────────────┘
                                         │
                                         ▼
┌────────────────────────────────────────────────────────────────────────────────────────┐
│                                 FIRESTORE DATABASE                                     │
│                                                                                        │
│  /exams/{examId}               --> Stores exam questions, customScoring, & points     │
│  /exams_metadata/{examId}      --> Stores summary for fast dashboard rendering          │
│  /submissions/{subId}          --> Stores student answers, raw score, & scaled score    │
│  /exam_results_cover/{examId}  --> Results cover sheet for instant stats              │
└────────────────────────────────────────────────────────────────────────────────────────┘
```

### Data Schema Updates

#### 1. Entity `Exam` (`/exams/{examId}`):
```typescript
interface CustomScoringConfig {
  multipleChoice: number; // VD: 0.25 hoặc 0.5
  trueFalse1: number;     // Đúng 1 ý
  trueFalse2: number;     // Đúng 2 ý
  trueFalse3: number;     // Đúng 3 ý
  trueFalse4: number;     // Đúng cả 4 ý
  shortAnswer: number;    // VD: 0.5 hoặc 1.0
}

interface Question {
  id: string;
  type: 'multiple_choice' | 'true_false' | 'short_answer';
  content: string;
  options?: string[];
  correctAnswer: string;
  explanation?: string;
  imageUrls?: string[];
  point?: number; // Điểm riêng tùy chỉnh cho câu hỏi này (Optional)
}

interface Exam {
  id: string;
  title: string;
  teacherId: string;
  duration: number;
  status: 'draft' | 'published';
  examType?: 'thpt' | 'custom_quiz'; // Phân biệt loại đề
  customScoring?: CustomScoringConfig; // Cấu hình điểm mặc định theo loại câu
  assignedClasses: string[];
  questions: Question[];
  createdAt: string;
  startTime?: string;
  endTime?: string;
}
```

#### 2. Entity `Submission` (`/submissions/{subId}`):
```typescript
interface Submission {
  id: string;
  examId: string;
  studentId: string;
  studentName: string;
  studentClass: string;
  answers: string; // JSON string
  score: number; // Điểm quy đổi thang 10
  rawScore?: number; // Điểm thực tế đạt được
  maxRawScore?: number; // Điểm tối đa thực tế của đề
  incorrectQuestions: string[];
  submittedAt: string;
}
```

---

## 5. Sequential Implementation Steps

### Bước 1: Cập nhật Router & Giao diện Bảng điều khiển Giáo viên (`TeacherDashboard.tsx`)
- Thêm Tab mới **"B p trắc nghiệm"** (`custom_quizzes`) vào thanh điều hướng Sidebar của Giáo viên.
- Hiển thị danh sách đề thi tùy chỉnh phân loại theo Khối lớp, kèm các nút chức năng: *Tạo đề mới*, *Chỉnh sửa*, *Gia hạn*, *Xem kết quả*, *Bảng vàng xếp hạng*, *Xóa*.
- Nút **"T p trắc nghiệm"** mở `ExamBuilder` ở chế độ `isCustomQuizMode = true`.

### Bước 2: Nâng cấp Trình tạo Đề thi (`ExamBuilder.tsx`)
- Thêm bộ điều khiển **Cấu hình Barem Điểm Mặc Định** (cho phép nhập số điểm cho từng loại câu hỏi).
- Thêm ô nhập **Điểm lẻ cho từng câu hỏi** trong danh sách các câu hỏi đã trích xuất, tự động hiển thị tổng điểm tối đa của đề thi.
- Lưu thuộc tính `examType: 'custom_quiz'`, `customScoring` và `point` của từng câu vào Firestore `/exams/{examId}` và `/exams_metadata/{examId}`.

### Bước 3: Nâng cấp Bộ chấm điểm tự động & Giao diện Làm bài (`TakeExam.tsx` & `ExamResults.tsx`)
- Cập nhật hàm `calculateScore` hỗ trợ tính điểm theo `q.point` lẻ hoặc `customScoring`.
- Tự động quy đổi về thang 10 chuẩn khi lưu vào `submissions` và `exam_results_cover`.
- Hiển thị chi tiết bảng điểm, điểm câu đúng/sai trong `StudentExamResult.tsx` và `ExamResults.tsx`.

### Bước 4: Kiểm thử & Xác minh
- Biên dịch ứng dụng (`compile_applet`) và kiểm tra cú pháp TypeScript (`lint_applet`).
- Xác minh luồng tạo đề, giao bài, học sinh làm bài và xem bảng điểm kết quả.

---

## Plan Verification Checklist
- [x] Đã làm rõ yêu cầu cấu hình điểm với Giáo viên (Cho phép cả điểm mặc định theo loại câu + đè điểm lẻ).
- [x] Không sửa đổi mã nguồn ứng dụng trong bước lập kế hoạch.
- [x] Sơ đồ kiến trúc ASCII và định dạng dữ liệu Firestore rõ ràng, chính xác.
- [x] Đảm bảo tương thích ngược 100% với các đề thi chuẩn THPT hiện có.
