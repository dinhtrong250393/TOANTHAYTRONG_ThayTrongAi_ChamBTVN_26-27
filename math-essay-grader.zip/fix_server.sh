awk '
/app.post\("\/api\/solve-textbook-exercise"/,/res.status\(500\)/ {
    if ($0 ~ /app.post\("\/api\/solve-textbook-exercise"/) skip = 1;
}
!skip { print $0 }
/res.status\(500\)/ { skip = 0; next }
' server.ts > temp_server.ts && mv temp_server.ts server.ts

# Now append it correctly before /api/ocr-images
awk '
/app.post\("\/api\/ocr-images"/ {
    print "  app.post(\"/api/solve-textbook-exercise\", async (req, res) => {"
    print "    try {"
    print "      const { imageBase64 } = req.body;"
    print "      if (!imageBase64) return res.status(400).json({ error: \"No image provided.\" });"
    print ""
    print "      const prompt = `Bạn là một giáo viên Toán học xuất sắc. Hình ảnh tôi cung cấp là một phần cắt từ Sách giáo khoa hoặc Sách bài tập, chứa MỘT BÀI TẬP DUY NHẤT. Hãy đọc, giải chi tiết và chia barem điểm cho bài tập này (tổng 10 điểm).\\n\\nTrình bày theo định dạng JSON sau:\\n{\\n  \"title\": \"Tên bài tập (VD: Bài 1, Câu 2...)\",\\n  \"questionText\": \"Nội dung câu hỏi (ghi lại đầy đủ đề bài, dùng ký hiệu unicode toán học thông thường, KHÔNG dùng LaTeX)\",\\n  \"solutionText\": \"Nội dung bài giải chi tiết, từng bước rõ ràng. Đi kèm mỗi bước là số điểm của bước đó, ví dụ: [Điểm: 0.25]. TỔNG ĐIỂM CÁC BƯỚC PHẢI LÀ 10.0.\"\\n}`;"
    print ""
    print "      let mimeType = \"image/jpeg\";"
    print "      let base64Data = imageBase64;"
    print "      const matchData = imageBase64.match(/^data:(image\\/[a-z]+);base64,([\\s\\S]+)$/);"
    print "      if (matchData) {"
    print "        mimeType = matchData[1];"
    print "        base64Data = matchData[2].trim();"
    print "      }"
    print ""
    print "      let ai = getGoogleGenAI(undefined);"
    print "      const response = await ai.models.generateContent({"
    print "        model: \"gemini-3.6-flash\","
    print "        contents: ["
    print "          { text: prompt },"
    print "          { inlineData: { mimeType, data: base64Data } }"
    print "        ],"
    print "        config: {"
    print "          responseMimeType: \"application/json\""
    print "        }"
    print "      });"
    print "      "
    print "      res.json(JSON.parse(response.text));"
    print "    } catch (err: any) {"
    print "      console.error(\"[API Solve Textbook ERROR]:\", err);"
    print "      res.status(500).json({ error: err.message || \"Lỗi giải bài SGK\" });"
    print "    }"
    print "  });"
    print ""
}
{ print $0 }
' server.ts > temp_server.ts && mv temp_server.ts server.ts
