import express from "express";
import path from "path";
import fs from "fs";
import { createServer as createViteServer } from "vite";
import { GoogleGenAI } from "@google/genai";
import dotenv from "dotenv";
import { CONFIGURED_GEMINI_KEYS } from "./src/lib/geminiKeys.js";
import { db } from "./src/lib/firebase.js";
import { doc, getDoc, setDoc, updateDoc, writeBatch } from "firebase/firestore";

dotenv.config({ override: true });

async function startServer() {
  const app = express();
  const PORT = 3000;

  app.use(express.json({ limit: "50mb" }));
  app.use(express.urlencoded({ limit: "50mb", extended: true }));

  const rawKeys = [
    ...(process.env.GEMINI_API_KEYS ? process.env.GEMINI_API_KEYS.split(/[,;\s]+/) : []),
    ...(process.env.GEMINI_API_KEY ? [process.env.GEMINI_API_KEY] : []),
    ...CONFIGURED_GEMINI_KEYS
  ].map(k => k.trim()).filter(Boolean);
  const GEMINI_API_KEYS_POOL: string[] = Array.from(new Set(rawKeys));
  console.log(`[Gemini Rotation] Loaded ${GEMINI_API_KEYS_POOL.length} unique Gemini API keys in pool.`);

  let currentKeyIndex = 0;
  // Key cooldown map: key -> timestamp when it becomes available again
  const keyCooldowns = new Map<string, number>();

  async function executeWithKeyRotation<T>(
    customApiKey: string | undefined,
    fn: (ai: GoogleGenAI, key: string) => Promise<T>
  ): Promise<T> {
    if (customApiKey?.trim()) {
      const ai = new GoogleGenAI({ apiKey: customApiKey.trim() });
      return await fn(ai, customApiKey.trim());
    }

    if (GEMINI_API_KEYS_POOL.length === 0) {
      throw new Error("Chưa cấu hình API Key nào trong hệ thống.");
    }

    let lastError: any = null;
    const startIndex = currentKeyIndex;
    const totalKeys = GEMINI_API_KEYS_POOL.length;
    const now = Date.now();

    // Find eligible keys (not currently in cooldown)
    let eligibleIndices: number[] = [];
    for (let i = 0; i < totalKeys; i++) {
      const idx = (startIndex + i) % totalKeys;
      const key = GEMINI_API_KEYS_POOL[idx];
      const cooldownUntil = keyCooldowns.get(key) || 0;
      if (now >= cooldownUntil) {
        eligibleIndices.push(idx);
      }
    }

    // If all keys are currently cooling down, calculate minimum wait time
    if (eligibleIndices.length === 0) {
      const waitTimes = GEMINI_API_KEYS_POOL.map(k => Math.max(1, Math.ceil(((keyCooldowns.get(k) || now) - now) / 1000)));
      const minWaitSec = Math.min(...waitTimes);
      const err: any = new Error(`Toàn bộ ${totalKeys} API Key tạm thời chạm giới hạn yêu cầu (429 Rate Limit - Quota Exhausted).`);
      err.retryAfterSeconds = Math.max(10, minWaitSec);
      throw err;
    }

    for (const idx of eligibleIndices) {
      const key = GEMINI_API_KEYS_POOL[idx];
      currentKeyIndex = (idx + 1) % totalKeys;

      try {
        const ai = new GoogleGenAI({ apiKey: key });
        const result = await fn(ai, key);
        // Clear cooldown upon success
        keyCooldowns.delete(key);
        return result;
      } catch (err: any) {
        lastError = err;
        const msg = err.message || "";
        const isQuotaOrLimit = msg.includes("429") || msg.includes("Quota") || msg.includes("Resource Exhausted") || msg.includes("503") || msg.includes("UNAVAILABLE");
        if (isQuotaOrLimit) {
          let delaySeconds = 45;
          const matchSeconds = msg.match(/retry in\s*([0-9.]+)\s*s/i) || msg.match(/"retryDelay":\s*"([0-9]+)s"/i);
          if (matchSeconds) {
            delaySeconds = Math.ceil(parseFloat(matchSeconds[1])) + 2;
          }
          keyCooldowns.set(key, Date.now() + delaySeconds * 1000);
          console.warn(`[KeyRotation] Key ${idx + 1}/${totalKeys} chạm giới hạn (cooldown ${delaySeconds}s). Tự động chuyển sang key khác...`);
          continue;
        }
        throw err;
      }
    }

    const waitTimes = GEMINI_API_KEYS_POOL.map(k => Math.max(1, Math.ceil(((keyCooldowns.get(k) || Date.now()) - Date.now()) / 1000)));
    const minWaitSec = Math.min(...waitTimes);
    const quotaErr: any = new Error(`Toàn bộ ${totalKeys} API Key tạm thời chạm giới hạn yêu cầu (429 Rate Limit - Quota Exhausted).`);
    quotaErr.retryAfterSeconds = Math.max(10, minWaitSec);
    throw quotaErr;
  }

  app.get("/api/health", (req, res) => {
    res.json({ status: "ok" });
  });

  app.post("/api/solve-textbook-exercise", async (req, res) => {
    try {
      const { imageBase64, studentApiKey } = req.body;
      if (!imageBase64) return res.status(400).json({ error: "Missing imageBase64" });

      let mimeType = "image/jpeg";
      let base64Data = imageBase64;
      const matchData = imageBase64.match(/^data:(image\/[a-zA-Z]+);base64,([\s\S]+)$/);
      if (matchData) {
        mimeType = matchData[1];
        base64Data = matchData[2].trim();
      }

      const prompt = `Bạn là một chuyên gia giáo dục. Hãy phân tích hình ảnh và trả về JSON hợp lệ theo định dạng:
{
  "title": "Tên bài",
  "questionText": "Đề bài",
  "solutionText": "Lời giải chi tiết"
}`;

      const result = await executeWithKeyRotation(studentApiKey, async (ai) => {
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents: [
            { text: prompt },
            { inlineData: { mimeType, data: base64Data } }
          ],
          config: {
            responseMimeType: "application/json"
          }
        });
        let text = response.text || "";
        const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
        if (match) text = match[1];
        text = text.trim();
        let sanitizedText = text.replace(/\\([^"\\/bfnrtu])/g, '\\\\$1');
        try {
          return JSON.parse(sanitizedText);
        } catch {
          return JSON.parse(text);
        }
      });

      res.json(result);
    } catch (error: any) {
      console.error("[solve-textbook-exercise error]:", error);
      res.status(500).json({ error: error.message || "Failed to solve" });
    }
  });

  app.post("/api/grade-essay", async (req, res) => {
    try {
      const { submission, essay, studentApiKey, teacherApiKey } = req.body;
      const effectiveCustomKey = (teacherApiKey?.trim()) || (studentApiKey?.trim());

      const prompt = `Bạn là một giáo viên chấm thi tự luận.
Dưới đây là một bài làm tự luận của học sinh (đã được đính kèm dưới dạng hình ảnh) cùng với Đề bài và Lời giải mẫu (đáp án chuẩn).

Nhiệm vụ của bạn:
1. Đọc và nhận diện chữ viết tay/công thức toán học từ hình ảnh bài làm.
2. Cảnh báo nếu hình ảnh quá mờ, không thể đọc được.
3. Đối chiếu từng bước giải quyết trong bài làm của học sinh với lời giải chuẩn.
4. NẾU học sinh giải quyết bài toán theo một cách KHÁC biệt so với đáp án chuẩn NHƯNG logic vẫn đúng và ra kết quả đúng, HÃY CÔNG NHẬN CÁCH LÀM ĐÓ và cho điểm tối đa cho phần đó.
5. Đưa ra nhận xét chi tiết, công tâm: chỉ ra điểm đúng, điểm sai, lỗi tư duy hoặc lỗi tính toán (nếu có), và gọi ý cách khắc phục.
6. KIỂM TRA KỸ THANG ĐIỂM (BAREM): Bạn BẮT BUỘC phải bám sát thang điểm (barem) của từng ý, từng câu được ghi trong Đề bài hoặc Lời giải chuẩn. 
   - NẾU câu A được giao 5.0 điểm, BẠN CHỈ ĐƯỢC CHẤM TỐI ĐA 5.0 ĐIỂM cho câu A (không được chấm 4.0 hay 6.0).
   - Cộng tổng điểm đạt được một cách chính xác và lô-gic nhất (từ 0 đến 10, có thể lẻ đến 0.25).

LƯU Ý QUAN TRỌNG VỀ JSON: NẾU TRONG NHẬN XÉT CÓ SỬ DỤNG CÔNG THỨC TOÁN HỌC LATEX (VD: \\infty, \\geq), BẠN PHẢI ESCAPE DẤU BACKSLASH THÀNH 2 DẤU (VD: \\\\infty, \\\\geq) ĐỂ ĐẢM BẢO CHUỖI JSON HỢP LỆ.

TRẢ VỀ KẾT QUẢ DƯỚI DẠNG JSON TUYỆT ĐỐI THEO ĐỊNH DẠNG SAU:
{
  "score": <điểm số là một số, ví dụ 8.5>,
  "aiFeedback": "<nhận xét chi tiết của bạn>"
}

--- Thông tin bài toán ---
Đề bài:
${essay.questionText || 'Không có văn bản đề bài'}

Lời giải chuẩn:
${essay.solutionText || 'Không có lời giải chuẩn, hãy tự giải và chấm theo tư duy logic.'}`;

      const contents: any[] = [];
      contents.push({ text: prompt });

      // Process images
      if (submission.images && submission.images.length > 0) {
        let sharpInstance: any;
        try {
          const sharpModule = await import('sharp');
          sharpInstance = sharpModule.default;
        } catch (e) {
          console.warn('sharp not available, skipping image compression');
        }

        for (const imgUrl of submission.images) {
          try {
            const imgRes = await fetch(imgUrl, { signal: AbortSignal.timeout(12000) });
            const arrayBuffer = await imgRes.arrayBuffer();
            let buffer = Buffer.from(arrayBuffer);
            let mimeType = imgRes.headers.get('content-type') || 'image/jpeg';

            if (sharpInstance) {
              buffer = await sharpInstance(buffer)
                .resize({ width: 1200, withoutEnlargement: true })
                .jpeg({ quality: 75 })
                .toBuffer();
              mimeType = 'image/jpeg';
            }

            contents.push({
              inlineData: {
                data: buffer.toString('base64'),
                mimeType: mimeType
              }
            });
          } catch (imgErr) {
            console.error('Error processing image:', imgUrl, imgErr);
          }
        }
      } else {
        // Fallback to OCR text if no images (legacy support)
        contents.push({ text: "Bài làm của học sinh (đã OCR từ ảnh):\n" + (submission.submissionImages?.join('\n') || '') });
      }

      const candidateModels = ["gemini-3.8-flash", "gemini-2.5-flash"];
      let result: any = null;
      let lastErr: any = null;

      for (const modelName of candidateModels) {
        try {
          result = await executeWithKeyRotation(effectiveCustomKey, async (ai) => {
            const response = await ai.models.generateContent({
              model: modelName,
              contents: contents,
              config: {
                responseMimeType: "application/json"
              }
            });
            let text = response.text || "";
            const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
            if (match) text = match[1];
            text = text.trim();
            let sanitizedText = text.replace(/\\([^"\\/bfnrtu])/g, '\\\\$1');
            try {
              return JSON.parse(sanitizedText);
            } catch {
              return JSON.parse(text);
            }
          });
          if (result) break;
        } catch (mErr) {
          lastErr = mErr;
        }
      }
      if (!result && lastErr) throw lastErr;

      res.json(result);
    } catch (error: any) {
      console.error("[GradeEssay Final Error]:", error);
      const rawMsg = error.message || "";
      const isQuota = rawMsg.includes("429") || rawMsg.includes("Resource Exhausted") || rawMsg.includes("Quota");
      if (isQuota) {
        res.status(429).json({ 
          error: error.message || "Toàn bộ API Key tạm thời chạm giới hạn yêu cầu (429 Rate Limit - Quota Exhausted).", 
          retryAfterSeconds: error.retryAfterSeconds || 30 
        });
      } else if (rawMsg.includes("503") || rawMsg.includes("UNAVAILABLE")) {
        res.status(503).json({ error: "Máy chủ AI của Google đang tạm bận. Thầy/Cô vui lòng bấm 'Thử chấm lại' sau ít giây." });
      } else {
        res.status(500).json({ error: rawMsg || "Đã xảy ra lỗi khi chấm điểm tự luận." });
      }
    }
  });

  app.post("/api/ocr-images", async (req, res) => {
    try {
      const { images, prompt, studentApiKey } = req.body;
      if (!images || !images.length) return res.status(400).json({ error: "No images provided" });

      const contents: any[] = [];
      if (prompt) contents.push({ text: prompt });
      else contents.push({ text: "Vui lòng đọc và trích xuất toàn bộ chữ/công thức từ các ảnh này." });

      for (const imgBase64 of images) {
        let mimeType = "image/jpeg";
        let base64Data = imgBase64;
        const matchData = imgBase64.match(/^data:(image\/[a-zA-Z]+);base64,([\s\S]+)$/);
        if (matchData) {
          mimeType = matchData[1];
          base64Data = matchData[2].trim();
        }
        contents.push({ inlineData: { mimeType, data: base64Data } });
      }

      const result = await executeWithKeyRotation(studentApiKey, async (ai) => {
        const response = await ai.models.generateContent({
          model: "gemini-3.8-flash",
          contents,
        });
        return response.text || "";
      });

      res.json({ success: true, text: result });
    } catch (error: any) {
      console.error("[OCR Error]:", error);
      res.status(500).json({ error: error.message || "Failed to OCR" });
    }
  });

  // --- BATCH GRADING ROUTES & BACKGROUND WORKER ---
  interface BatchJob {
    essayId: string;
    status: "running" | "completed" | "stopped" | "failed";
    total: number;
    completed: number;
    results: Record<string, any>;
    shouldStop: boolean;
    solutionTextCache?: string;
  }
  const batchJobs = new Map<string, BatchJob>();
  const CHECKPOINT_DIR = path.resolve("/tmp/essay_batch_jobs");
  if (!fs.existsSync(CHECKPOINT_DIR)) {
    try { fs.mkdirSync(CHECKPOINT_DIR, { recursive: true }); } catch {}
  }

  function saveJobCheckpoint(job: BatchJob) {
    try {
      const filePath = path.join(CHECKPOINT_DIR, `${job.essayId}.json`);
      fs.writeFileSync(filePath, JSON.stringify(job), "utf8");
    } catch (e) {
      console.warn("[BatchJob] Checkpoint save warning:", e);
    }
  }

  function getJobCheckpoint(essayId: string): BatchJob | null {
    if (batchJobs.has(essayId)) return batchJobs.get(essayId)!;
    try {
      const filePath = path.join(CHECKPOINT_DIR, `${essayId}.json`);
      if (fs.existsSync(filePath)) {
        const data = JSON.parse(fs.readFileSync(filePath, "utf8"));
        batchJobs.set(essayId, data);
        return data;
      }
    } catch {}
    return null;
  }

  const sanitizeFirestoreObj = (obj: any) => {
    if (!obj || typeof obj !== 'object') return obj;
    const clean: any = {};
    for (const key of Object.keys(obj)) {
      clean[key] = obj[key] !== undefined ? obj[key] : null;
    }
    return clean;
  };

  async function commitBatchResultsDirectly(essayId: string, resultsMap: Record<string, any>) {
    const resultsList = Object.values(resultsMap || {});
    if (resultsList.length === 0) return;

    try {
      console.log(`[BatchWorker AutoCommit] Bắt đầu tự động lưu ${resultsList.length} kết quả cho đề ${essayId} lên Firestore...`);

      // 1. Commit individual submissions in WriteBatch (chunks of 400)
      const CHUNK_SIZE = 400;
      for (let i = 0; i < resultsList.length; i += CHUNK_SIZE) {
        const chunk = resultsList.slice(i, i + CHUNK_SIZE);
        const batch = writeBatch(db);
        for (const res of chunk) {
          const subDocRef = doc(db, 'essay_submissions', res.id);
          const updatePayload = sanitizeFirestoreObj({
            score: res.score !== undefined ? res.score : null,
            aiFeedback: res.aiFeedback !== undefined ? res.aiFeedback : null,
            status: res.status || 'submitted',
            errorMsg: res.errorMsg !== undefined ? res.errorMsg : null,
            gradedAt: res.gradedAt || Date.now()
          });
          batch.set(subDocRef, updatePayload, { merge: true });
        }
        await batch.commit().catch(e => console.warn("[Batch commit warning]:", e));
      }

      // 2. Fetch existing summary from essay_results_cover
      const coverRef = doc(db, 'essay_results_cover', essayId);
      const coverSnap = await getDoc(coverRef).catch(() => null);
      let submissionSummary: any[] = coverSnap?.exists() ? (coverSnap.data().submissionSummary || []) : [];

      for (const res of resultsList) {
        const cleanRes = sanitizeFirestoreObj(res);
        const idx = submissionSummary.findIndex((s: any) => s.id === cleanRes.id);
        if (idx !== -1) {
          submissionSummary[idx] = { ...submissionSummary[idx], ...cleanRes };
        } else {
          submissionSummary.push(cleanRes);
        }
      }

      const cleanSummary = submissionSummary.map(item => sanitizeFirestoreObj(item));

      // 3. Multi-layer cover update
      await setDoc(coverRef, { submissionSummary: cleanSummary }, { merge: true }).catch(e => console.warn("cover update warning:", e));
      await setDoc(doc(db, 'essays', essayId), { submissionSummary: cleanSummary }, { merge: true }).catch(e => console.warn("essays update warning:", e));
      await setDoc(doc(db, 'essays_metadata', essayId), { submissionSummary: cleanSummary }, { merge: true }).catch(e => console.warn("essays_metadata update warning:", e));

      // 4. Update student profile completedEssays
      await Promise.all(
        resultsList.map(async (res) => {
          if (res.studentId) {
            try {
              const userRef = doc(db, 'users', res.studentId);
              const userSnap = await getDoc(userRef);
              if (userSnap.exists()) {
                const userData = userSnap.data();
                const completedEssays = userData.completedEssays || [];
                const index = completedEssays.findIndex((c: any) => c.essayId === essayId);
                if (index !== -1) {
                  completedEssays[index] = { 
                    ...completedEssays[index], 
                    score: res.score !== undefined ? res.score : null, 
                    status: res.status || 'graded' 
                  };
                  await updateDoc(userRef, { completedEssays });
                } else {
                  completedEssays.push({
                    essayId,
                    submissionId: res.id,
                    score: res.score !== undefined ? res.score : null,
                    status: res.status || 'graded',
                    submittedAt: new Date().toISOString()
                  });
                  await updateDoc(userRef, { completedEssays });
                }
              }
            } catch (userErr) {
              console.warn(`[BatchWorker AutoCommit] Warning updating user ${res.studentId}:`, userErr);
            }
          }
        })
      );

      console.log(`[BatchWorker AutoCommit] Đã tự động lưu thành công toàn bộ ${resultsList.length} bài vào Firestore!`);
    } catch (commitErr) {
      console.error("[BatchWorker AutoCommit Error]:", commitErr);
    }
  }

  app.post("/api/batch-grade/start", async (req, res) => {
    try {
      const { essayId, essay, targetSubmissions, teacherApiKey } = req.body;
      if (!essayId || !targetSubmissions || !Array.isArray(targetSubmissions)) {
        return res.status(400).json({ error: "Tham số không hợp lệ" });
      }

      const effectiveCustomKey = teacherApiKey?.trim() || undefined;

      const job: BatchJob = {
        essayId,
        status: "running",
        total: targetSubmissions.length,
        completed: 0,
        results: {},
        shouldStop: false
      };
      batchJobs.set(essayId, job);
      saveJobCheckpoint(job);

      // Run background worker asynchronously
      (async () => {
        let sharpInstance: any = null;
        try {
          const sharpModule = await import('sharp');
          sharpInstance = sharpModule.default;
        } catch (e) {}

        // 1. One-time Teacher Solution OCR / Cache
        let effectiveSolutionText = essay?.solutionText || "";
        if (!effectiveSolutionText && essay?.solutionImages && essay.solutionImages.length > 0) {
          console.log(`[Batch Worker] Đang OCR đáp án chuẩn của Giáo viên (chạy 1 lần cho cả lớp)...`);
          try {
            const solContents: any[] = [{ text: "Bạn là chuyên gia OCR toán học. Hãy đọc và ghi lại CHÍNH XÁC lời giải/đáp án mẫu của giáo viên trong hình ảnh thành văn bản rõ ràng." }];
            for (const solImg of essay.solutionImages) {
              const imgRes = await fetch(solImg, { signal: AbortSignal.timeout(12000) });
              const arrayBuffer = await imgRes.arrayBuffer();
              let buffer = Buffer.from(arrayBuffer);
              let mimeType = imgRes.headers.get('content-type') || 'image/jpeg';
              if (sharpInstance) {
                buffer = await sharpInstance(buffer)
                  .resize({ width: 1200, withoutEnlargement: true })
                  .jpeg({ quality: 75 })
                  .toBuffer();
                mimeType = 'image/jpeg';
              }
              solContents.push({ inlineData: { data: buffer.toString('base64'), mimeType } });
            }

            const solResult = await executeWithKeyRotation(effectiveCustomKey, async (ai) => {
              const resp = await ai.models.generateContent({
                model: "gemini-3.8-flash",
                contents: solContents
              });
              return resp.text || "";
            });
            if (solResult) {
              effectiveSolutionText = solResult;
              job.solutionTextCache = effectiveSolutionText;
              console.log(`[Batch Worker] OCR đáp án chuẩn hoàn tất (${effectiveSolutionText.length} ký tự).`);
            }
          } catch (ocrErr) {
            console.warn("[Batch Worker] Lỗi OCR đáp án chuẩn, dùng suy luận logic:", ocrErr);
            effectiveSolutionText = "Không có văn bản đáp án chuẩn, hãy tự giải và chấm theo tư duy logic.";
          }
        }

        const CONCURRENCY = 6;
        let index = 0;

        async function worker() {
          while (index < targetSubmissions.length && !job.shouldStop) {
            const subIdx = index++;
            const sub = targetSubmissions[subIdx];
            if (!sub) break;

            let attempt = 0;
            const maxAttempts = 3; // 1 lần đầu + 2 lần thử lại theo yêu cầu
            let gradedResult: any = null;

            while (attempt < maxAttempts && !gradedResult && !job.shouldStop) {
              attempt++;
              try {
                const prompt = `Bạn là một giáo viên chấm thi tự luận.
Dưới đây là một bài làm tự luận của học sinh (đã được đính kèm dưới dạng hình ảnh) cùng với Đề bài và Lời giải mẫu (đáp án chuẩn).

Nhiệm vụ của bạn:
1. Đọc và nhận diện chữ viết tay/công thức toán học từ hình ảnh bài làm.
2. Cảnh báo nếu hình ảnh quá mờ, không thể đọc được.
3. Đối chiếu từng bước giải quyết trong bài làm của học sinh với lời giải chuẩn.
4. NẾU học sinh giải quyết bài toán theo một cách KHÁC biệt so với đáp án chuẩn NHƯNG logic vẫn đúng và ra kết quả đúng, HÃY CÔNG NHẬN CÁCH LÀM ĐÓ và cho điểm tối đa cho phần đó.
5. Đưa ra nhận xét chi tiết, công tâm: chỉ ra điểm đúng, điểm sai, lỗi tư duy hoặc lỗi tính toán (nếu có), và gợi ý cách khắc phục.
6. KIỂM TRA KỸ THANG ĐIỂM (BAREM): Bạn BẮT BUỘC phải bám sát thang điểm (barem) của từng ý, từng câu được ghi trong Đề bài hoặc Lời giải chuẩn. 
   - NẾU câu A được giao 5.0 điểm, BẠN CHỈ ĐƯỢC CHẤM TỐI ĐA 5.0 ĐIỂM cho câu A (không được chấm 4.0 hay 6.0).
   - Cộng tổng điểm đạt được một cách chính xác và lô-gic nhất (từ 0 đến 10, có thể lẻ đến 0.25).

LƯU Ý QUAN TRỌNG VỀ JSON: NẾU TRONG NHẬN XÉT CÓ SỬ DỤNG CÔNG THỨC TOÁN HỌC LATEX (VD: \\infty, \\geq), BẠN PHẢI ESCAPE DẤU BACKSLASH THÀNH 2 DẤU (VD: \\\\infty, \\\\geq) ĐỂ ĐẢM BẢO CHUỖI JSON HỢP LỆ.

TRẢ VỀ KẾT QUẢ DƯỚI DẠNG JSON TUYỆT ĐỐI THEO ĐỊNH DẠNG SAU:
{
  "score": <điểm số là một số, ví dụ 8.5>,
  "aiFeedback": "<nhận xét chi tiết của bạn>"
}

--- Thông tin bài toán ---
Đề bài:
${essay?.questionText || 'Không có văn bản đề bài'}

Lời giải chuẩn:
${effectiveSolutionText || essay?.solutionText || 'Không có lời giải chuẩn, hãy tự giải và chấm theo tư duy logic.'}`;

                const contents: any[] = [{ text: prompt }];

                if (sub.images && sub.images.length > 0) {
                  for (const imgUrl of sub.images) {
                    try {
                      const imgRes = await fetch(imgUrl, { signal: AbortSignal.timeout(12000) });
                      const arrayBuffer = await imgRes.arrayBuffer();
                      let buffer = Buffer.from(arrayBuffer);
                      let mimeType = imgRes.headers.get('content-type') || 'image/jpeg';

                      if (sharpInstance) {
                        buffer = await sharpInstance(buffer)
                          .resize({ width: 1200, withoutEnlargement: true })
                          .jpeg({ quality: 75 })
                          .toBuffer();
                        mimeType = 'image/jpeg';
                      }

                      contents.push({
                        inlineData: {
                          data: buffer.toString('base64'),
                          mimeType
                        }
                      });
                    } catch (imgErr) {
                      console.error("[Batch Worker Image Error]:", imgErr);
                    }
                  }
                }

                const candidateModels = ["gemini-3.8-flash", "gemini-2.5-flash"];
                let result: any = null;
                let lastErr: any = null;

                for (const modelName of candidateModels) {
                  try {
                    result = await executeWithKeyRotation(effectiveCustomKey, async (ai) => {
                      const response = await ai.models.generateContent({
                        model: modelName,
                        contents,
                        config: { responseMimeType: "application/json" }
                      });
                      let text = response.text || "";
                      const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
                      if (match) text = match[1];
                      text = text.trim();
                      let sanitizedText = text.replace(/\\([^"\\/bfnrtu])/g, '\\\\$1');
                      try {
                        return JSON.parse(sanitizedText);
                      } catch {
                        return JSON.parse(text);
                      }
                    });
                    if (result) break;
                  } catch (mErr) {
                    lastErr = mErr;
                  }
                }
                if (!result && lastErr) throw lastErr;

                gradedResult = {
                  id: sub.id,
                  studentId: sub.studentId,
                  studentName: sub.studentName,
                  score: typeof result.score === 'number' ? result.score : (parseFloat(result.score) || 0),
                  aiFeedback: result.aiFeedback || 'Đã chấm xong.',
                  status: 'graded',
                  gradedAt: Date.now()
                };
              } catch (err: any) {
                console.warn(`[Batch Worker Error sub ${sub.id}] Lần ${attempt}/${maxAttempts}:`, err.message);
                if (attempt < maxAttempts) {
                  await new Promise(res => setTimeout(res, 1500));
                }
              }
            }

            if (job.shouldStop) break;

            if (gradedResult) {
              job.results[sub.id] = gradedResult;
            } else {
              // Mark as grading_failed after 3 attempts
              job.results[sub.id] = {
                id: sub.id,
                studentId: sub.studentId,
                studentName: sub.studentName,
                score: null,
                status: 'grading_failed',
                aiFeedback: 'Ảnh chụp mờ hoặc lỗi nhận diện sau 3 lần thử. Thầy/Cô vui lòng chấm tay.',
                errorMsg: 'Ảnh chụp mờ hoặc lỗi nhận diện sau 3 lần thử. Thầy/Cô vui lòng chấm tay.',
                gradedAt: Date.now()
              };
            }
            job.completed++;
            saveJobCheckpoint(job);
          }
        }

        const workers = Array.from({ length: CONCURRENCY }, () => worker());
        await Promise.all(workers);

        if (job.shouldStop) {
          job.status = "stopped";
        } else {
          job.status = "completed";
        }
        saveJobCheckpoint(job);

        // AUTO-COMMIT TO FIRESTORE DIRECTLY FROM SERVER
        await commitBatchResultsDirectly(essayId, job.results);
      })().catch((bgErr) => {
        console.error("[Batch Job Fatal Error]:", bgErr);
        job.status = "failed";
        saveJobCheckpoint(job);
      });

      res.json({ success: true, message: "Bắt đầu chấm đồng loạt thành công" });
    } catch (error: any) {
      console.error("[batch-grade/start Error]:", error);
      res.status(500).json({ error: error.message || "Lỗi khi khởi động chấm đồng loạt" });
    }
  });

  app.get("/api/batch-grade/status", (req, res) => {
    const essayId = req.query.essayId as string;
    if (!essayId) {
      return res.json(null);
    }
    const job = getJobCheckpoint(essayId);
    if (!job) {
      return res.json(null);
    }
    res.json({
      essayId: job.essayId,
      status: job.status,
      total: job.total,
      completed: job.completed,
      results: job.results
    });
  });

  app.post("/api/batch-grade-essay", (req, res) => {
    // Acknowledge single/batch background grading trigger
    res.json({ success: true, message: "Yêu cầu chấm ngầm đã được tiếp nhận" });
  });

  app.post("/api/batch-grade/stop", (req, res) => {
    const { essayId } = req.body;
    if (essayId && batchJobs.has(essayId)) {
      const job = batchJobs.get(essayId)!;
      job.shouldStop = true;
      job.status = "stopped";
      saveJobCheckpoint(job);
    }
    res.json({ success: true });
  });

  app.post("/api/batch-grade/clear", (req, res) => {
    const { essayId } = req.body;
    if (essayId) {
      batchJobs.delete(essayId);
      try {
        const filePath = path.join(CHECKPOINT_DIR, `${essayId}.json`);
        if (fs.existsSync(filePath)) fs.unlinkSync(filePath);
      } catch {}
    }
    res.json({ success: true });
  });

  if (process.env.NODE_ENV !== "production") {
    const vite = await createViteServer({
      server: { middlewareMode: true },
      appType: "spa",
    });
    app.use(vite.middlewares);
  } else {
    const distPath = path.join(process.cwd(), "dist");
    app.use(express.static(distPath));
    app.get("*", (req, res) => {
      res.sendFile(path.join(distPath, "index.html"));
    });
  }

  app.listen(PORT, "0.0.0.0", () => {
    console.log(`Server running on port ${PORT}`);
  });
}

startServer();
