import React, { createContext, useContext, useEffect, useState } from 'react';
import { User, onAuthStateChanged, signOut, GoogleAuthProvider, signInWithPopup } from 'firebase/auth';
import { doc, getDoc, setDoc, collection, query, where, getDocs, onSnapshot } from 'firebase/firestore';
import { auth, db, handleFirestoreError, OperationType } from './firebase';

export type UserRole = 'teacher' | 'student';

export interface AppUser {
  uid: string;
  email: string;
  role: UserRole;
  name: string;
  className?: string;
  facebook?: string;
  zalo?: string;
  createdAt: string;
  completedExams?: any[];
  completedEssays?: any[];
  schoolInfo?: string;
  personalEmail?: string;
  dob?: string;
  address?: string;
  parentName?: string;
  parentRelation?: string;
  parentPhone?: string;
}

interface AuthContextType {
  user: User | null;
  appUser: AppUser | null;
  loading: boolean;
  loginWithGoogle: () => Promise<void>;
  logout: () => Promise<void>;
  refreshAppUser: () => Promise<void>;
}

const AuthContext = createContext<AuthContextType>({
  user: null,
  appUser: null,
  loading: true,
  loginWithGoogle: async () => {},
  logout: async () => {},
  refreshAppUser: async () => {},
});

export const useAuth = () => useContext(AuthContext);

export const AuthProvider: React.FC<{ children: React.ReactNode }> = ({ children }) => {
  const [user, setUser] = useState<User | null>(null);
  const [appUser, setAppUser] = useState<AppUser | null>(null);
  const [loading, setLoading] = useState(true);

  const refreshAppUser = async () => {
    if (!user) return;
    try {
      const userDocRef = doc(db, 'users', user.uid);
      const userDoc = await getDoc(userDocRef);
      if (userDoc.exists()) {
        setAppUser(userDoc.data() as AppUser);
      }
    } catch (err) {
      console.error("Error refreshing appUser:", err);
    }
  };

  useEffect(() => {
    const unsubscribe = onAuthStateChanged(auth, async (firebaseUser) => {
      setUser(firebaseUser);
      if (firebaseUser) {
        try {
          const userDocRef = doc(db, "users", firebaseUser.uid);
          const userDoc = await getDoc(userDocRef);
          if (userDoc.exists()) {
            setAppUser(userDoc.data() as AppUser);
            setLoading(false);
          } else {
            const q = query(collection(db, "users"), where("role", "==", "teacher"));
            const querySnapshot = await getDocs(q);
            if (querySnapshot.empty) {
              const newUser: AppUser = {
                uid: firebaseUser.uid,
                email: firebaseUser.email || "",
                role: "teacher",
                name: firebaseUser.displayName || "Giáo viên",
                createdAt: new Date().toISOString(),
              };
              await setDoc(userDocRef, newUser);
              setAppUser(newUser);
              setLoading(false);
            } else {
              // Check if existing teacher has the same email (e.g. logging in with different UID)
              const existingTeacher = querySnapshot.docs[0].data();
              const existingEmail = (existingTeacher.email || '').toLowerCase();
              const currentEmail = (firebaseUser.email || '').toLowerCase();
              if (existingEmail && currentEmail && existingEmail === currentEmail) {
                const updatedTeacher: AppUser = {
                  ...(existingTeacher as AppUser),
                  uid: firebaseUser.uid,
                  name: firebaseUser.displayName || existingTeacher.name || 'Giáo viên',
                  email: firebaseUser.email || existingTeacher.email,
                  role: 'teacher'
                };
                await setDoc(userDocRef, updatedTeacher);
                setAppUser(updatedTeacher);
                setLoading(false);
              } else {
                // Check if user exists by email in users collection (for students)
                const qStudent = query(collection(db, "users"), where("email", "==", firebaseUser.email || ""));
                const studentSnap = await getDocs(qStudent).catch(() => null);
                if (studentSnap && !studentSnap.empty) {
                  const studentData = studentSnap.docs[0].data() as AppUser;
                  const linkedStudent: AppUser = { ...studentData, uid: firebaseUser.uid };
                  await setDoc(userDocRef, linkedStudent).catch(() => {});
                  setAppUser(linkedStudent);
                  setLoading(false);
                } else {
                  await signOut(auth);
                  setAppUser(null);
                  setUser(null);
                  setLoading(false);
                }
              }
            }
          }
        } catch (error: any) {
          console.error("Error fetching user data:", error);
          if (error.code === "resource-exhausted") {
            console.warn("Firestore quota exceeded.");
          }
          setLoading(false);
        }
      } else {
        setAppUser(null);
        setLoading(false);
      }
    });
    return () => {
      unsubscribe();
    };
  }, []);

  const loginWithGoogle = async () => {
    const provider = new GoogleAuthProvider();
    try {
      const result = await signInWithPopup(auth, provider);
      const firebaseUser = result.user;
      
      const userDocRef = doc(db, 'users', firebaseUser.uid);
      const userDoc = await getDoc(userDocRef);
      
      if (!userDoc.exists()) {
        const q = query(collection(db, 'users'), where('role', '==', 'teacher'));
        const querySnapshot = await getDocs(q);
        
        if (!querySnapshot.empty) {
          const existingTeacher = querySnapshot.docs[0].data();
          const existingEmail = (existingTeacher.email || '').toLowerCase();
          const currentEmail = (firebaseUser.email || '').toLowerCase();
          if (existingEmail && currentEmail && existingEmail === currentEmail) {
            const newUser: AppUser = {
              ...(existingTeacher as AppUser),
              uid: firebaseUser.uid,
              name: firebaseUser.displayName || existingTeacher.name || 'Giáo viên',
              email: firebaseUser.email || existingTeacher.email,
              role: 'teacher'
            };
            await setDoc(userDocRef, newUser);
            setAppUser(newUser);
          } else {
            await signOut(auth);
            throw new Error(`Hệ thống đã có tài khoản giáo viên (${existingEmail}). Bạn không thể đăng nhập bằng tài khoản Google khác.`);
          }
        }
      }
    } catch (error) {
      console.error("Error signing in with Google", error);
      throw error;
    }
  };

  const logout = async () => {
    await signOut(auth);
  };

  return (
    <AuthContext.Provider value={{ user, appUser, loading, loginWithGoogle, logout, refreshAppUser }}>
      {children}
    </AuthContext.Provider>
  );
};
