/**
 * Bulletproof JSON parser for AI outputs that may contain LaTeX formulas with raw backslashes
 */
export function safeParseJson(raw: string): any {
  if (!raw || typeof raw !== 'string') {
    throw new Error('Chuỗi kết quả trống từ AI');
  }

  let text = raw.trim();
  const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
  if (match) text = match[1].trim();

  // 1. Try direct standard parse
  try {
    return JSON.parse(text);
  } catch {}

  // 2. Escape non-JSON backslashes (LaTeX formulas like \alpha, \times, \frac, \sqrt)
  try {
    const sanitized = text.replace(/\\(?!(["\\/bfnrt]|u[0-9a-fA-F]{4}))/g, "\\\\");
    return JSON.parse(sanitized);
  } catch {}

  // 3. Fallback: Direct regex extraction of score and feedback
  const scoreMatch = text.match(/"score"\s*:\s*([0-9.]+)/i);
  const feedbackMatch =
    text.match(/"aiFeedback"\s*:\s*"([\s\S]*?)"\s*\}/i) ||
    text.match(/"aiFeedback"\s*:\s*"([\s\S]*?)"/i);

  if (scoreMatch) {
    const parsedScore = parseFloat(scoreMatch[1]);
    let feedback = feedbackMatch ? feedbackMatch[1] : text;
    feedback = feedback.replace(/\\n/g, "\n").replace(/\\"/g, '"');
    return {
      score: parsedScore,
      aiFeedback: feedback
    };
  }

  // 4. Last resort: extract any number for score
  const anyScore = text.match(/(?:điểm|score|tong diem|tổng điểm)\s*[:=]?\s*([0-9.]+)/i);
  if (anyScore) {
    return {
      score: parseFloat(anyScore[1]),
      aiFeedback: text
    };
  }

  throw new Error("Không thể trích xuất kết quả điểm số từ phản hồi: " + text.substring(0, 100));
}
