import React, { useState, useEffect } from 'react';
import { useParams, Link, useLocation, useNavigate } from 'react-router-dom';
import { db, handleFirestoreError, OperationType, syncEssayResultsCover } from '../lib/firebase';
import { triggerZaloCampaign } from '../lib/zaloUtils';
import { syncClassStudentsCover } from '../lib/syncUtils';
import { collection, query, where, getDocs, getDoc, doc, updateDoc, deleteDoc, onSnapshot, setDoc, writeBatch } from 'firebase/firestore';
import { ArrowLeft, Loader2, Image as ImageIcon, FileText, CheckCircle, AlertCircle, RefreshCw, X, FileEdit, Calculator, Users, BarChart3, Send, Trash2, Sparkles, ZoomIn, ZoomOut, ChevronLeft, ChevronRight, Maximize, UserCheck, Filter, Key, StopCircle } from 'lucide-react';
import { LineChart, Line, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, LabelList } from 'recharts';
import { GoogleGenAI } from '@google/genai';
import ReactMarkdown from 'react-markdown';
import { gradeEssayClient } from '../lib/grader';
import Latex from 'react-latex-next';
import 'katex/dist/katex.min.css';

const renderMathChildren = (children: React.ReactNode): React.ReactNode => {
  if (typeof children === 'string') {
    const processedText = children
      .replace(/\\\(/g, () => '$')
      .replace(/\\\)/g, () => '$')
      .replace(/\\\[/g, () => '$$')
      .replace(/\\\]/g, () => '$$');
    return <Latex>{processedText}</Latex>;
  }
  if (Array.isArray(children)) {
    return children.map((child, idx) => (
      <React.Fragment key={idx}>{renderMathChildren(child)}</React.Fragment>
    ));
  }
  return children;
};

function ImageViewer({ images, initialIndex, onClose }: { images: string[], initialIndex: number, onClose: () => void }) {
  const [currentIndex, setCurrentIndex] = useState(initialIndex);
  const [zoom, setZoom] = useState(1);
  const [pan, setPan] = useState({ x: 0, y: 0 });
  const [isDragging, setIsDragging] = useState(false);
  const [dragStart, setDragStart] = useState({ x: 0, y: 0 });

  useEffect(() => {
    const handleKeyDown = (e: KeyboardEvent) => {
      if (e.key === 'Escape') onClose();
      if (e.key === 'ArrowRight') handleNext();
      if (e.key === 'ArrowLeft') handlePrev();
    };
    window.addEventListener('keydown', handleKeyDown);
    return () => window.removeEventListener('keydown', handleKeyDown);
  }, [currentIndex]);

  const handleNext = () => {
    if (currentIndex < images.length - 1) {
      setCurrentIndex(prev => prev + 1);
      resetZoom();
    }
  };

  const handlePrev = () => {
    if (currentIndex > 0) {
      setCurrentIndex(prev => prev - 1);
      resetZoom();
    }
  };

  const resetZoom = () => {
    setZoom(1);
    setPan({ x: 0, y: 0 });
  };

  const handleZoomIn = () => setZoom(prev => Math.min(prev + 0.5, 4));
  const handleZoomOut = () => setZoom(prev => Math.max(prev - 0.5, 0.5));

  const handleWheel = (e: React.WheelEvent) => {
    e.preventDefault();
    if (e.deltaY < 0) {
      handleZoomIn();
    } else {
      handleZoomOut();
    }
  };

  const handleMouseDown = (e: React.MouseEvent) => {
    if (zoom > 1) {
      setIsDragging(true);
      setDragStart({ x: e.clientX - pan.x, y: e.clientY - pan.y });
    }
  };

  const handleMouseMove = (e: React.MouseEvent) => {
    if (isDragging && zoom > 1) {
      setPan({
        x: e.clientX - dragStart.x,
        y: e.clientY - dragStart.y
      });
    }
  };

  const handleMouseUp = () => setIsDragging(false);

  return (
    <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/90 backdrop-blur-sm">
      <button onClick={onClose} className="absolute top-4 right-4 p-3 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-50">
        <X className="w-6 h-6" />
      </button>

      <div className="absolute top-4 left-1/2 -translate-x-1/2 flex items-center gap-4 bg-white/10 p-2 rounded-2xl backdrop-blur-md z-50">
        <button onClick={handleZoomOut} className="p-2 text-white hover:bg-white/20 rounded-xl transition-colors">
          <ZoomOut className="w-5 h-5" />
        </button>
        <span className="text-white font-medium min-w-[3rem] text-center">{Math.round(zoom * 100)}%</span>
        <button onClick={handleZoomIn} className="p-2 text-white hover:bg-white/20 rounded-xl transition-colors">
          <ZoomIn className="w-5 h-5" />
        </button>
        <div className="w-px h-6 bg-white/20 mx-2"></div>
        <button onClick={resetZoom} className="p-2 text-white hover:bg-white/20 rounded-xl transition-colors" title="Fit Screen">
          <Maximize className="w-5 h-5" />
        </button>
      </div>

      {currentIndex > 0 && (
        <button onClick={handlePrev} className="absolute left-4 top-1/2 -translate-y-1/2 p-4 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-50">
          <ChevronLeft className="w-8 h-8" />
        </button>
      )}

      {currentIndex < images.length - 1 && (
        <button onClick={handleNext} className="absolute right-4 top-1/2 -translate-y-1/2 p-4 bg-white/10 hover:bg-white/20 text-white rounded-full transition-colors z-50">
          <ChevronRight className="w-8 h-8" />
        </button>
      )}

      <div className="absolute bottom-4 left-1/2 -translate-x-1/2 text-white/70 font-medium bg-black/50 px-4 py-2 rounded-full z-50">
        Ảnh {currentIndex + 1} / {images.length}
      </div>

      <div 
        className="w-full h-full flex items-center justify-center overflow-hidden"
        onWheel={handleWheel}
        onMouseDown={handleMouseDown}
        onMouseMove={handleMouseMove}
        onMouseUp={handleMouseUp}
        onMouseLeave={handleMouseUp}
      >
        <img 
          src={images[currentIndex]} 
          alt={`Bài làm ${currentIndex + 1}`}
          className="max-h-[90vh] max-w-[90vw] object-contain transition-transform duration-200"
          style={{ 
            transform: `scale(${zoom}) translate(${pan.x / zoom}px, ${pan.y / zoom}px)`,
            cursor: zoom > 1 ? (isDragging ? 'grabbing' : 'grab') : 'zoom-in'
          }}
          onClick={() => zoom === 1 && handleZoomIn()}
          draggable={false}
        />
      </div>
    </div>
  );
}

export default function EssayResults() {
  const { essayId } = useParams<{ essayId: string }>();
  const location = useLocation();
  const navigate = useNavigate();
  const [essay, setEssay] = useState<any>(null);
  const [submissions, setSubmissions] = useState<any[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState<string | null>(null);
  const [selectedSubmission, setSelectedSubmission] = useState<any>(null);
  const [loadingFullSubmission, setLoadingFullSubmission] = useState(false);
  const [isRefreshing, setIsRefreshing] = useState(false);
  const [isEditingGrade, setIsEditingGrade] = useState(false);
  const [editedScore, setEditedScore] = useState('');
  const [editedFeedback, setEditedFeedback] = useState('');
  const [isSavingEdit, setIsSavingEdit] = useState(false);
  const [viewerImageIndex, setViewerImageIndex] = useState<number | null>(null);

  const handleSelectSubmission = async (sub: any) => {
    if (!sub) {
      setSelectedSubmission(null);
      setIsEditingGrade(false);
      return;
    }
    // Set basic info instantly to prevent transition lag
    setSelectedSubmission(sub);
    setIsEditingGrade(false);
    setLoadingFullSubmission(true);
    try {
      const subDoc = await getDoc(doc(db, 'essay_submissions', sub.id));
      if (subDoc.exists()) {
        const fullData = subDoc.data();
        setSelectedSubmission(prev => ({
          ...sub,
          ...fullData,
          status: (fullData.status === 'graded' ? 'graded' : sub.status) || fullData.status,
          score: fullData.score !== undefined && fullData.score !== null ? fullData.score : sub.score,
          aiFeedback: fullData.aiFeedback || sub.aiFeedback || prev?.aiFeedback
        }));
      }
    } catch (err) {
      console.error("Lỗi tải chi tiết bài làm:", err);
    } finally {
      setLoadingFullSubmission(false);
    }
  };

  // Keep full details in sync if the summary status updates (e.g., grading finishes)
  useEffect(() => {
    if (!selectedSubmission) return;
    const currentSubInList = submissions.find(s => s.id === selectedSubmission.id);
    if (currentSubInList) {
      setSelectedSubmission(prev => {
        if (!prev) return prev;
        if (
          prev.status !== currentSubInList.status ||
          prev.score !== currentSubInList.score ||
          prev.aiFeedback !== currentSubInList.aiFeedback
        ) {
          return {
            ...prev,
            ...currentSubInList,
            images: prev.images || currentSubInList.images
          };
        }
        return prev;
      });
    }
  }, [submissions]);

  const [isGrading, setIsGrading] = useState(false);
  const [gradingError, setGradingError] = useState('');
  const [students, setStudents] = useState<any[]>([]);
  const [classes, setClasses] = useState<any[]>([]);
  const [loadingNotificationData, setLoadingNotificationData] = useState(false);
  const [showNotifyModal, setShowNotifyModal] = useState(false);
  const [selectedNotifyClass, setSelectedNotifyClass] = useState<string>('');
  const [selectedFilterClass, setSelectedFilterClass] = useState<string>('ALL');
  const [submissionToDelete, setSubmissionToDelete] = useState<string | null>(null);
  const [isDeleting, setIsDeleting] = useState(false);
  const [isGradingAll, setIsGradingAll] = useState(false);
  const [isRetryingErrors, setIsRetryingErrors] = useState(false);
  const [gradingProgress, setGradingProgress] = useState({ total: 0, current: 0 });
  const [activeStudentName, setActiveStudentName] = useState<string>('');
  const [gradingStatusText, setGradingStatusText] = useState<string>('');
  const [showApiKeyModal, setShowApiKeyModal] = useState(false);
  const [customTeacherApiKey, setCustomTeacherApiKey] = useState<string>(() => {
    return (typeof window !== 'undefined' ? localStorage.getItem('teacher_gemini_api_key') || '' : '');
  });
  const [tempApiKeyInput, setTempApiKeyInput] = useState<string>('');
  const shouldStopBatchRef = React.useRef<boolean>(false);
  const [showBatchConfirm, setShowBatchConfirm] = useState(false);
  const [showBatchSuccess, setShowBatchSuccess] = useState(false);
  const [showRetryConfirm, setShowRetryConfirm] = useState(false);
  const [showRetrySuccess, setShowRetrySuccess] = useState(false);
  const [noUngradedAlert, setNoUngradedAlert] = useState(false);
  const [noFailedAlert, setNoFailedAlert] = useState(false);
  const [batchGradingIds, setBatchGradingIds] = useState<string[]>([]);
   // oops need useAuth if used? Actually no need for useAuth here unless it's missing.
  
  const sortedSubmissions = React.useMemo(() => {
    return [...submissions].sort((a, b) => new Date(a.submittedAt).getTime() - new Date(b.submittedAt).getTime());
  }, [submissions]);

  const scoreData = React.useMemo(() => {
    const counts: Record<string, number> = {
      '0.0': 0, '0.5': 0, '1.0': 0, '1.5': 0, '2.0': 0, '2.5': 0, '3.0': 0, '3.5': 0, '4.0': 0, '4.5': 0,
      '5.0': 0, '5.5': 0, '6.0': 0, '6.5': 0, '7.0': 0, '7.5': 0, '8.0': 0, '8.5': 0, '9.0': 0, '9.5': 0, '10.0': 0
    };
    
    submissions.forEach(sub => {
      if (sub.status === 'graded') {
        const score = parseFloat(sub.score);
        if (!isNaN(score)) {
          const roundedScore = (Math.round(score * 2) / 2).toFixed(1);
          if (counts[roundedScore] !== undefined) {
            counts[roundedScore]++;
          }
        }
      }
    });

    return Object.keys(counts).map(score => ({
      name: score,
      count: counts[score]
    }));
  }, [submissions]);

  const updateBothSubAndEssay = async (submissionId: string, updates: any) => {
    // 1. Update the submission document (1 Write with merge)
    const subRef = doc(db, 'essay_submissions', submissionId);
    await setDoc(subRef, updates, { merge: true }).catch(() => updateDoc(subRef, updates));

    if (!essayId) return;

    // 2. Locally compute the updated summary
    const updatedSubmissions = submissions.map(s => {
      if (s.id === submissionId) {
        return { ...s, ...updates };
      }
      return s;
    });

    // 3. Write directly to the inner results cover sheet (essay_results_cover)
    // This is 1 Write and 0 Reads!
    const coverRef = doc(db, 'essay_results_cover', essayId);
    await setDoc(coverRef, {
      submissionSummary: updatedSubmissions
    }, { merge: true });

    // Update local React state directly
    setSubmissions(updatedSubmissions);
    setEssay(prev => {
      if (!prev) return prev;
      return { ...prev, submissionSummary: updatedSubmissions };
    });
    setSelectedSubmission(prev => {
      if (prev && prev.id === submissionId) {
        return { ...prev, ...updates };
      }
      return prev;
    });
  };

  const handleDeleteSubmission = async () => {
    if (!submissionToDelete) return;
    setIsDeleting(true);
    try {
      const sub = submissions.find(s => s.id === submissionToDelete);
      
      await deleteDoc(doc(db, 'essay_submissions', submissionToDelete));
      
      if (sub && sub.studentId) {
        const userRef = doc(db, 'users', sub.studentId);
        const userDoc = await getDoc(userRef);
        if (userDoc.exists()) {
          const userData = userDoc.data();
          if (userData.completedEssays) {
            try {
              const newCompletedEssays = userData.completedEssays.filter(
                (c: any) => c.essayId !== essayId && c.submissionId !== submissionToDelete
              );
              await updateDoc(userRef, { completedEssays: newCompletedEssays });
            } catch (err) {
              console.error("Lỗi cập nhật user doc:", err);
            }
          }
        }
      }

      // Remove from essay.submissionSummary across all covers
      if (essayId) {
        const essayRef = doc(db, 'essays', essayId);
        const essaySnap = await getDoc(essayRef);
        let newSummary: any[] = [];
        if (essaySnap.exists()) {
          const essayData = essaySnap.data();
          const summary = essayData.submissionSummary || [];
          newSummary = summary.filter((item: any) => item.id !== submissionToDelete);
          await updateDoc(essayRef, { submissionSummary: newSummary }).catch(() => {});
          await updateDoc(doc(db, 'essays_metadata', essayId), { submissionSummary: newSummary }).catch(() => {});
        } else {
          newSummary = submissions.filter(s => s.id !== submissionToDelete);
        }
        
        // Update inner cover sheet directly with 0 Reads
        await setDoc(doc(db, 'essay_results_cover', essayId), {
          submissionSummary: newSummary
        }, { merge: true }).catch(() => {});
      }

      setSubmissions(submissions.filter(s => s.id !== submissionToDelete));
      setEssay(prev => {
        if (!prev) return prev;
        const summary = prev.submissionSummary || [];
        const newSummary = summary.filter((item: any) => item.id !== submissionToDelete);
        return { ...prev, submissionSummary: newSummary };
      });
      if (selectedSubmission?.id === submissionToDelete) {
        setSelectedSubmission(null);
      }
      setSubmissionToDelete(null);
    } catch (error) {
      console.error("Lỗi khi xóa bài làm:", error);
    } finally {
      setIsDeleting(false);
    }
  };

  useEffect(() => {
    if (!essayId) return;
    
    setLoading(true);

    let unsubscribe: () => void;
    
    const loadDataAndListen = async () => {
      try {
        const essayDoc = await getDoc(doc(db, 'essays', essayId));
        const originalEssayData = essayDoc.exists() ? essayDoc.data() : {};

        const coverRef = doc(db, 'essay_results_cover', essayId);
        
        unsubscribe = onSnapshot(coverRef, async (coverSnap) => {
          let submissionsList: any[] = [];
          let essayData: any = null;

          if (coverSnap.exists()) {
            const coverData = coverSnap.data();
            submissionsList = coverData.submissionSummary || [];
            essayData = {
              id: essayId,
              ...originalEssayData,
              title: coverData.title || originalEssayData.title || '',
              submissionSummary: submissionsList
            };
          } else {
            const cover = await syncEssayResultsCover(essayId);
            submissionsList = cover.submissionSummary || [];
            essayData = {
              id: essayId,
              ...originalEssayData,
              title: cover.title || originalEssayData.title || '',
              submissionSummary: submissionsList
            };
          }

          setEssay(essayData);
          setSubmissions(submissionsList);

      // --- FIX: PROACTIVELY LOAD STUDENTS FOR ZALO NOTIFICATIONS ---
      let studs: any[] = [];
      if (essayData && essayData.assignedClasses && essayData.assignedClasses.length > 0) {
        for (const cls of essayData.assignedClasses) {
          const classCoverDoc = await getDoc(doc(db, 'class_students_cover', cls));
          if (classCoverDoc.exists()) {
            const data = classCoverDoc.data();
            studs = studs.concat((data.students || []).map((s: any) => ({ ...s, className: cls })));
          } else {
            const syncStuds = await syncClassStudentsCover(cls);
            studs = studs.concat((syncStuds || []).map((s: any) => ({ ...s, className: cls })));
          }
        }
      }
      setStudents(studs);
      // --- END FIX ---
          
          setLoading(false);
        }, (error) => {
          console.error("Lỗi lắng nghe dữ liệu:", error);
          setError("Lỗi đồng bộ dữ liệu theo thời gian thực.");
          setLoading(false);
        });

        // Check if there is an active background batch job on the server
        fetch(`/api/batch-grade/status?essayId=${essayId}`)
          .then(res => res.json())
          .then(async (job) => {
            if (job && job.status === 'running') {
              setIsGradingAll(true);
              setGradingProgress({ total: job.total, current: job.completed });
              setGradingStatusText(`Đang tiếp tục chấm ngầm (8 làn song song)... Hoàn thành: ${job.completed}/${job.total} bài.`);
              pollRunningJob(essayId);
            } else if (job && (job.status === 'completed' || job.status === 'stopped') && job.results && Object.keys(job.results).length > 0) {
              await commitBatchResultsToFirestore(essayId, job.results);
              await fetch('/api/batch-grade/clear', {
                method: 'POST',
                headers: { 'Content-Type': 'application/json' },
                body: JSON.stringify({ essayId })
              }).catch(() => {});
            }
          })
          .catch(() => {});

      } catch (err: any) {
        console.error(err);
        setError('Lỗi tải dữ liệu. Vui lòng thử lại.');
        setLoading(false);
      }
    };

    loadDataAndListen();
    
    return () => {
      if (unsubscribe) unsubscribe();
    };
  }, [essayId]);

  const handleManualRefresh = async () => {
    if (!essayId) return;
    setIsRefreshing(true);
    try {
      // Refresh by forcing sync of the essay results cover first
      const cover = await syncEssayResultsCover(essayId);
      
      const essayDoc = await getDoc(doc(db, 'essays', essayId));
      const originalEssayData = essayDoc.exists() ? essayDoc.data() : {};

      const submissionsList = cover.submissionSummary || [];
      const essayData: any = {
        id: essayId,
        ...originalEssayData,
        title: cover.title || originalEssayData.title || '',
        submissionSummary: submissionsList
      };
      
      setEssay(essayData);
      setSubmissions(submissionsList);

      // Fetch students immediately to show class groupings
      let studs: any[] = [];
      if (essayData && essayData.assignedClasses && essayData.assignedClasses.length > 0) {
        for (const cls of essayData.assignedClasses) {
          const classCoverDoc = await getDoc(doc(db, 'class_students_cover', cls));
          if (classCoverDoc.exists()) {
            const data = classCoverDoc.data();
            studs = studs.concat((data.students || []).map((s: any) => ({ ...s, className: cls })));
          } else {
            const syncStuds = await syncClassStudentsCover(cls);
            studs = studs.concat((syncStuds || []).map((s: any) => ({ ...s, className: cls })));
          }
        }
      }
      setStudents(studs);
      
      if (selectedSubmission) {
        const freshSub = submissionsList.find((s: any) => s.id === selectedSubmission.id);
        if (freshSub) {
          try {
            const subDoc = await getDoc(doc(db, 'essay_submissions', selectedSubmission.id));
            if (subDoc.exists()) {
              const fullData = subDoc.data();
              setSelectedSubmission({
                ...freshSub,
                ...fullData,
                status: (fullData.status === 'graded' ? 'graded' : freshSub.status) || fullData.status,
                score: fullData.score !== undefined && fullData.score !== null ? fullData.score : freshSub.score,
                aiFeedback: fullData.aiFeedback || freshSub.aiFeedback || selectedSubmission.aiFeedback
              });
            } else {
              setSelectedSubmission(freshSub);
            }
          } catch (e) {
            setSelectedSubmission(freshSub);
          }
        }
      }
    } catch (err) {
      console.error("Lỗi khi tải lại dữ liệu:", err);
    } finally {
      setIsRefreshing(false);
    }
  };

  // Progress is now managed directly and reliably inside runBackgroundGrading

  const handleGradeAI = async (submission: any) => {
    setIsGrading(true);
    setGradingError('');
    try {
              await updateBothSubAndEssay(submission.id, { status: 'grading_in_progress' });

        // Ensure full submission details and images are loaded
        let fullSub = submission;
        if (!fullSub.images || fullSub.images.length === 0) {
          try {
            const subDoc = await getDoc(doc(db, "essay_submissions", submission.id));
            if (subDoc.exists()) {
              fullSub = { id: subDoc.id, ...subDoc.data() };
            }
          } catch (fetchErr) {
            console.error("Lỗi tải chi tiết bài làm đơn:", fetchErr);
          }
        }

        const { aiFeedback, score } = await gradeEssayClient(fullSub, essay, customTeacherApiKey);

        const newSubData = {
          aiFeedback: aiFeedback,
          score: score,
          status: 'graded',
          gradedAt: new Date().getTime()
        };

        await updateBothSubAndEssay(submission.id, newSubData);
        setSelectedSubmission(prev => prev && prev.id === submission.id ? { ...prev, ...newSubData } : prev);
        
        // Update student's profile completed essays
        try {
          const userRef = doc(db, 'users', submission.studentId);
          const userSnap = await getDoc(userRef);
          if (userSnap.exists()) {
            const userData = userSnap.data();
            const completedEssays = userData.completedEssays || [];
            const index = completedEssays.findIndex((c: any) => c.essayId === essayId);
            if (index !== -1) {
              completedEssays[index] = {
                ...completedEssays[index],
                score: score,
                status: 'graded'
              };
              await updateDoc(userRef, { completedEssays });
            } else {
              completedEssays.push({
                essayId: essayId,
                submissionId: submission.id,
                score: score,
                status: 'graded',
                submittedAt: submission.submittedAt || new Date().toISOString()
              });
              await updateDoc(userRef, { completedEssays });
            }
          }
        } catch (userErr) {
          console.error("Lỗi cập nhật hồ sơ học sinh:", userErr);
        }
    } catch (err: any) {
      setGradingError('Lỗi chấm điểm: ' + err.message);
        try {
          const failedData = {
            status: 'grading_failed',
            errorMsg: err.message || 'Lỗi chấm bài.'
          };
          await updateBothSubAndEssay(submission.id, failedData);
          setSelectedSubmission(prev => prev && prev.id === submission.id ? { ...prev, ...failedData } : prev);
        } catch (upErr) {
          console.error("Lỗi cập nhật trạng thái thất bại:", upErr);
        }
    } finally {
      setIsGrading(false);
    }
  };

  const handleStartEdit = () => {
    if (!selectedSubmission) return;
    setEditedScore(selectedSubmission.score !== undefined && selectedSubmission.score !== null ? selectedSubmission.score.toString() : '0');
    setEditedFeedback(selectedSubmission.aiFeedback || '');
    setIsEditingGrade(true);
  };

  const handleSaveEditGrade = async () => {
    if (!selectedSubmission) return;
    const scoreVal = parseFloat(editedScore);
    if (isNaN(scoreVal) || scoreVal < 0 || scoreVal > 10) {
      alert('Vui lòng nhập điểm số hợp lệ từ 0 đến 10.');
      return;
    }

    setIsSavingEdit(true);
    try {
      const newSubData = {
        aiFeedback: editedFeedback,
        score: scoreVal,
        status: 'graded',
        gradedAt: new Date().getTime()
      };

      await updateBothSubAndEssay(selectedSubmission.id, newSubData);

      // Update student's profile completed essays
      try {
        const userRef = doc(db, 'users', selectedSubmission.studentId);
        const userSnap = await getDoc(userRef);
        if (userSnap.exists()) {
          const userData = userSnap.data();
          const completedEssays = userData.completedEssays || [];
          const index = completedEssays.findIndex((c: any) => c.essayId === essayId);
          if (index !== -1) {
            completedEssays[index] = {
              ...completedEssays[index],
              score: scoreVal,
              status: 'graded'
            };
            await updateDoc(userRef, { completedEssays });
          } else {
            completedEssays.push({
              essayId: essayId,
              submissionId: selectedSubmission.id,
              score: scoreVal,
              status: 'graded',
              submittedAt: selectedSubmission.submittedAt || new Date().toISOString()
            });
            await updateDoc(userRef, { completedEssays });
          }
        }
      } catch (userErr) {
        console.error("Lỗi cập nhật hồ sơ học sinh:", userErr);
      }

      setIsEditingGrade(false);
      alert('Cập nhật điểm và nhận xét thành công!');
    } catch (err: any) {
      alert("Lỗi khi cập nhật điểm: " + err.message);
    } finally {
      setIsSavingEdit(false);
    }
  };

  const handleRetryErrorsAI = () => {
    const failedSubs = submissions.filter(s => s.status === 'grading_failed' || s.status === 'key_error');
    if (failedSubs.length === 0) {
      setNoFailedAlert(true);
      return;
    }
    setShowRetryConfirm(true);
  };

  const handleStopBatch = async () => {
    shouldStopBatchRef.current = true;
    setGradingStatusText('Đang gửi lệnh dừng khẩn cấp đến máy chủ...');
    if (essayId) {
      try {
        await fetch('/api/batch-grade/stop', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ essayId })
        });
      } catch (stopErr) {
        console.error("Lỗi gửi lệnh dừng:", stopErr);
      }
    }
  };

  const commitBatchResultsToFirestore = async (essayIdStr: string, resultsMap: Record<string, any>) => {
    const resultsList = Object.values(resultsMap || {});
    if (resultsList.length === 0) return;

    try {
      setGradingStatusText('Đang ghi đồng loạt kết quả lên hệ thống...');

      // Helper to strictly remove any undefined fields (Firestore throws fatal error on undefined)
      const sanitize = (obj: any) => {
        if (!obj || typeof obj !== 'object') return obj;
        const clean: any = {};
        for (const key of Object.keys(obj)) {
          clean[key] = obj[key] !== undefined ? obj[key] : null;
        }
        return clean;
      };

      // 1. Fetch current cover sheet or fallback to current state
      const coverRef = doc(db, 'essay_results_cover', essayIdStr);
      const coverSnap = await getDoc(coverRef).catch(() => null);
      let submissionSummary: any[] = coverSnap?.exists() 
        ? (coverSnap.data().submissionSummary || []) 
        : [...submissions];

      for (const res of resultsList) {
        const cleanRes = sanitize(res);
        const idx = submissionSummary.findIndex((s: any) => s.id === cleanRes.id);
        if (idx !== -1) {
          submissionSummary[idx] = { ...submissionSummary[idx], ...cleanRes };
        } else {
          submissionSummary.push(cleanRes);
        }
      }

      // Ensure every item in submissionSummary is completely clean of undefined values
      const cleanSummary = submissionSummary.map(item => sanitize(item));

      // 2. Multi-layer cover update: Sync essay_results_cover, essays, and essays_metadata
      await setDoc(coverRef, { submissionSummary: cleanSummary }, { merge: true });

      const essayDocRef = doc(db, 'essays', essayIdStr);
      await setDoc(essayDocRef, { submissionSummary: cleanSummary }, { merge: true }).catch(e => console.warn("essays cover update warning:", e));

      const essayMetaDocRef = doc(db, 'essays_metadata', essayIdStr);
      await setDoc(essayMetaDocRef, { submissionSummary: cleanSummary }, { merge: true }).catch(e => console.warn("essays_metadata update warning:", e));

      // 3. Commit detailed submissions in Firestore WriteBatch (chunks of 400 to avoid Firestore limits)
      const CHUNK_SIZE = 400;
      for (let i = 0; i < resultsList.length; i += CHUNK_SIZE) {
        const chunk = resultsList.slice(i, i + CHUNK_SIZE);
        const batch = writeBatch(db);
        for (const res of chunk) {
          const subDocRef = doc(db, 'essay_submissions', res.id);
          const updatePayload = sanitize({
            score: res.score !== undefined ? res.score : null,
            aiFeedback: res.aiFeedback !== undefined ? res.aiFeedback : null,
            status: res.status || 'submitted',
            errorMsg: res.errorMsg !== undefined ? res.errorMsg : null,
            gradedAt: res.gradedAt || Date.now()
          });
          batch.set(subDocRef, updatePayload, { merge: true });
        }
        await batch.commit().catch(e => console.warn("[Batch commit warning]:", e));
      }

      // 4. Update student profile completedEssays if graded in parallel
      await Promise.all(
        resultsList.map(async (res) => {
          if (res.status === 'graded' && res.studentId) {
            try {
              const userRef = doc(db, 'users', res.studentId);
              const userSnap = await getDoc(userRef);
              if (userSnap.exists()) {
                const userData = userSnap.data();
                const completedEssays = userData.completedEssays || [];
                const index = completedEssays.findIndex((c: any) => c.essayId === essayIdStr);
                if (index !== -1) {
                  completedEssays[index] = { ...completedEssays[index], score: res.score, status: res.status };
                  await updateDoc(userRef, { completedEssays });
                } else {
                  completedEssays.push({
                    essayId: essayIdStr,
                    submissionId: res.id,
                    score: res.score,
                    status: res.status,
                    submittedAt: new Date().toISOString()
                  });
                  await updateDoc(userRef, { completedEssays });
                }
              }
            } catch {}
          }
        })
      );

      // 5. Update local React state instantly
      setSubmissions(cleanSummary);
      setEssay(prev => prev ? { ...prev, submissionSummary: cleanSummary } : prev);
      setSelectedSubmission(prev => {
        if (!prev) return prev;
        const fresh = cleanSummary.find((s: any) => s.id === prev.id);
        if (fresh) {
          return {
            ...prev,
            ...fresh,
            images: prev.images || fresh.images
          };
        }
        return prev;
      });
      console.log(`[BatchGrader] Đã ghi đồng loạt thành công ${resultsList.length} bài lên Firestore.`);
    } catch (err) {
      console.error("[BatchGrader] Lỗi ghi kết quả lên Firestore:", err);
      // Fallback: update local React state so teacher sees results even if Firestore was slow
      setSubmissions(prev => {
        return prev.map(s => {
          const res = resultsMap[s.id];
          return res ? { ...s, ...res } : s;
        });
      });
      setSelectedSubmission(prev => {
        if (!prev || !resultsMap[prev.id]) return prev;
        return { ...prev, ...resultsMap[prev.id] };
      });
    }
  };

  const pollRunningJob = async (essayIdStr: string) => {
    let isDone = false;
    while (!isDone && !shouldStopBatchRef.current) {
      await new Promise(res => setTimeout(res, 2000));
      if (shouldStopBatchRef.current) break;

      const statusRes = await fetch(`/api/batch-grade/status?essayId=${essayIdStr}`).catch(() => null);
      if (!statusRes || !statusRes.ok) continue;

      const job = await statusRes.json().catch(() => null);
      if (job) {
        setGradingProgress({ total: job.total, current: job.completed });
        setGradingStatusText(`Đang chấm tự động (8 làn song song)... Hoàn thành: ${job.completed}/${job.total} bài.`);

        if (job.status === 'completed' || job.status === 'stopped' || job.status === 'failed') {
          isDone = true;
          if (job.results && Object.keys(job.results).length > 0) {
            await commitBatchResultsToFirestore(essayIdStr, job.results);
          }
          await fetch('/api/batch-grade/clear', {
            method: 'POST',
            headers: { 'Content-Type': 'application/json' },
            body: JSON.stringify({ essayId: essayIdStr })
          }).catch(() => {});
          setIsGradingAll(false);
          setIsRetryingErrors(false);
          setShowBatchSuccess(true);
          break;
        }
      }
    }
  };

  const runBackgroundGrading = async (
    targetSubs: any[], 
    essayData: any, 
    essayIdStr: string, 
    idsList: string[],
    isRetryMode: boolean = false
  ) => {
    shouldStopBatchRef.current = false;
    
    try {
      setGradingStatusText(`Đang khởi động 8 làn chấm song song trên máy chủ...`);

      // 1. Fetch full details (images) for submissions that only have summary metadata in parallel
      setGradingStatusText(`Đang tải dữ liệu ảnh học sinh (${targetSubs.length} bài)...`);
      const enrichedTargetSubs = await Promise.all(
        targetSubs.map(async (sub) => {
          let fullSub = sub;
          if (!fullSub.images || fullSub.images.length === 0) {
            try {
              const subDoc = await getDoc(doc(db, "essay_submissions", sub.id));
              if (subDoc.exists()) {
                fullSub = { id: subDoc.id, ...subDoc.data() };
              }
            } catch (fetchErr) {
              console.warn("Lỗi tải chi tiết bài làm:", fetchErr);
            }
          }
          return {
            id: fullSub.id,
            studentId: fullSub.studentId,
            studentName: fullSub.studentName,
            images: fullSub.images || fullSub.submissionImages || [],
            status: fullSub.status
          };
        })
      );

      // 2. Start server background job
      const startRes = await fetch('/api/batch-grade/start', {
        method: 'POST',
        headers: { 'Content-Type': 'application/json' },
        body: JSON.stringify({
          essayId: essayIdStr,
          teacherApiKey: customTeacherApiKey || undefined,
          essay: {
            title: essayData?.title,
            questionText: essayData?.questionText,
            solutionText: essayData?.solutionText,
            solutionImages: essayData?.solutionImages || []
          },
          targetSubmissions: enrichedTargetSubs
        })
      });

      if (!startRes.ok) {
        const errJson = await startRes.json().catch(() => ({}));
        throw new Error(errJson.error || 'Không thể khởi động tiến trình chấm trên máy chủ');
      }

      // 3. Poll server job status every 2 seconds (0 Firestore reads!)
      let isDone = false;

      while (!isDone && !shouldStopBatchRef.current) {
        await new Promise(res => setTimeout(res, 2000));
        if (shouldStopBatchRef.current) break;

        const statusRes = await fetch(`/api/batch-grade/status?essayId=${essayIdStr}`);
        if (!statusRes.ok) continue;

        const job = await statusRes.json();
        if (job) {
          const currentCount = job.completed || 0;
          const totalCount = job.total || targetSubs.length;
          setGradingProgress({ total: totalCount, current: currentCount });
          setGradingStatusText(`Đang chấm tự động (8 làn song song)... Hoàn thành: ${currentCount}/${totalCount} bài.`);

          if (job.status === 'completed' || job.status === 'stopped' || job.status === 'failed') {
            isDone = true;
            // 4. Single Batch Commit to Firestore when completed or stopped
            if (job.results && Object.keys(job.results).length > 0) {
              await commitBatchResultsToFirestore(essayIdStr, job.results);
            }
            // Clear job on server
            await fetch('/api/batch-grade/clear', {
              method: 'POST',
              headers: { 'Content-Type': 'application/json' },
              body: JSON.stringify({ essayId: essayIdStr })
            }).catch(() => {});
            break;
          }
        }
      }

      if (shouldStopBatchRef.current) {
        // Fetch any remaining completed items and commit them
        const stopCheck = await fetch(`/api/batch-grade/status?essayId=${essayIdStr}`).then(r => r.json()).catch(() => null);
        if (stopCheck?.results && Object.keys(stopCheck.results).length > 0) {
          await commitBatchResultsToFirestore(essayIdStr, stopCheck.results);
        }
        await fetch('/api/batch-grade/clear', {
          method: 'POST',
          headers: { 'Content-Type': 'application/json' },
          body: JSON.stringify({ essayId: essayIdStr })
        }).catch(() => {});
        setGradingStatusText('Đã dừng tiến trình. Các bài đã hoàn tất được lưu đầy đủ.');
      }

    } catch (loopErr: any) {
      console.error("[Background Worker] Lỗi trong tiến trình chấm:", loopErr);
      setGradingStatusText('Gặp sự cố khi kết nối máy chủ: ' + loopErr.message);
    } finally {
      if (isRetryMode) {
        setIsRetryingErrors(false);
        if (!shouldStopBatchRef.current) setShowRetrySuccess(true);
      } else {
        setIsGradingAll(false);
        if (!shouldStopBatchRef.current) setShowBatchSuccess(true);
      }
      setBatchGradingIds([]);
      shouldStopBatchRef.current = false;
      setActiveStudentName('');
      setGradingStatusText('');
    }
  };

  const startRetryErrorsGrading = async () => {
    setShowRetryConfirm(false);
    shouldStopBatchRef.current = false;
    const failedSubs = submissions.filter(s => s.status === 'grading_failed' || s.status === 'key_error' || s.status === 'needs_manual_grading');
    if (failedSubs.length === 0) return;

    const ids = failedSubs.map(s => s.id);
    setBatchGradingIds(ids);
    setIsRetryingErrors(true);
    setGradingProgress({ total: ids.length, current: 0 });
    setActiveStudentName(failedSubs[0]?.studentName || 'Học sinh');
    setGradingStatusText('Bắt đầu chấm lại các bài bị lỗi (8 làn song song)...');

    // Optimistic UI update
    const optimisticSubs = submissions.map(sub => 
      ids.includes(sub.id) ? { ...sub, status: 'grading_in_progress' } : sub
    );
    setSubmissions(optimisticSubs);
    setSelectedSubmission(prev => prev && ids.includes(prev.id) ? { ...prev, status: 'grading_in_progress' } : prev);

    // Run background worker for retry
    runBackgroundGrading(failedSubs, essay, essayId || '', ids, true).catch(err => {
      console.error(err);
      setIsRetryingErrors(false);
      setBatchGradingIds([]);
    });
  };

  const handleGradeAllAI = () => {
    const targetSubs = submissions.filter(s => s.status === 'submitted' || s.status === 'grading_failed' || s.status === 'key_error' || s.status === 'needs_manual_grading' || s.status !== 'graded');
    if (targetSubs.length === 0) {
      setNoUngradedAlert(true);
      return;
    }
    setShowBatchConfirm(true);
  };

  const startBatchGrading = async () => {
    setShowBatchConfirm(false);
    shouldStopBatchRef.current = false;
    const targetSubs = submissions.filter(s => s.status === 'submitted' || s.status === 'grading_failed' || s.status === 'key_error' || s.status === 'needs_manual_grading' || s.status !== 'graded');
    if (targetSubs.length === 0) return;

    const ids = targetSubs.map(s => s.id);
    setBatchGradingIds(ids);
    setIsGradingAll(true);
    setGradingProgress({ total: ids.length, current: 0 });
    setActiveStudentName(targetSubs[0]?.studentName || 'Học sinh');
    setGradingStatusText('Bắt đầu khởi động chấm đồng loạt (8 làn song song)...');

    // Optimistic UI update
    const optimisticSubs = submissions.map(sub => 
      ids.includes(sub.id) ? { ...sub, status: 'grading_in_progress' } : sub
    );
    setSubmissions(optimisticSubs);
    setSelectedSubmission(prev => prev && ids.includes(prev.id) ? { ...prev, status: 'grading_in_progress' } : prev);

    // Run background worker
    runBackgroundGrading(targetSubs, essay, essayId || '', ids, false).catch(err => {
      console.error(err);
      setIsGradingAll(false);
      setBatchGradingIds([]);
    });
  };

  const handleNotify = async (sub: any) => {
    try {
      // Priority 1: Use embedded contact details if present
      let zalo = sub.studentZalo || null;
      let facebook = sub.studentFacebook || null;

      // Priority 2: Fall back to lazy loading if not present
      if (!zalo && !facebook && sub.studentId) {
        console.log(`[Lazy Loading] Fetching student contact info: ${sub.studentId}`);
        const userDoc = await getDoc(doc(db, 'users', sub.studentId));
        if (userDoc.exists()) {
          const userData = userDoc.data();
          zalo = userData.zalo || null;
          facebook = userData.facebook || null;

          // Locally update submissions list and selected submission so we don't query again next time
          setSubmissions(prev => prev.map(s => s.id === sub.id ? { ...s, studentZalo: zalo, studentFacebook: facebook } : s));
          if (selectedSubmission && selectedSubmission.id === sub.id) {
            setSelectedSubmission(prev => prev ? { ...prev, studentZalo: zalo, studentFacebook: facebook } : null);
          }
        }
      }

      const studentName = sub.studentName;
      const message = `🎉 KẾT QUẢ BÀI TỰ LUẬN 🎉\n\nChào ${studentName}, em đã hoàn thành bài: "${essay.title || 'Bài tập'}"\n\n🎯 Điểm số: ${sub.score || 0} / 10 điểm.\n👉 Hãy tiếp tục cố gắng nhé!\n🔗 Xem lại bài làm: ${window.location.origin}`;
      
      await navigator.clipboard.writeText(message);
      
      if (zalo) {
        window.open(`https://chat.zalo.me/?phone=${zalo}`, '_blank', 'noopener,noreferrer');
      } else if (facebook) {
        window.open(facebook, '_blank', 'noopener,noreferrer');
      } else {
        window.open(`https://chat.zalo.me/`, '_blank', 'noopener,noreferrer');
      }
    } catch (err) {
      console.error("Lỗi khi gửi thông báo:", err);
      window.open(`https://chat.zalo.me/`, '_blank', 'noopener,noreferrer');
    }
  };

  const loadNotificationData = async () => {
    if (classes.length > 0 && students.length > 0) return;
    setLoadingNotificationData(true);
    try {
      const qClasses = query(collection(db, 'classes'));
      const classesSnap = await getDocs(qClasses);
      const classesList = classesSnap.docs.map(doc => ({ id: doc.id, ...doc.data() }));
      setClasses(classesList);

      let studs: any[] = [];
      if (essay && essay.assignedClasses && essay.assignedClasses.length > 0) {
        for (const cls of essay.assignedClasses) {
          const coverDoc = await getDoc(doc(db, 'class_students_cover', cls));
          if (coverDoc.exists()) {
            const data = coverDoc.data();
            studs = studs.concat((data.students || []).map((s: any) => ({ ...s, className: cls })));
          } else {
            const syncStuds = await syncClassStudentsCover(cls);
            studs = studs.concat((syncStuds || []).map((s: any) => ({ ...s, className: cls })));
          }
        }
      }
      setStudents(studs);
    } catch (err) {
      console.error("Error loading notification data:", err);
    } finally {
      setLoadingNotificationData(false);
    }
  };

  const notifyScoreZalo = (target: 'student' | 'parent') => {
    if (!essay) return;
    const gradedSubs = submissions.filter(s => s.status === 'graded' && s.score !== undefined && s.score !== null);
    if (gradedSubs.length === 0) {
      alert("Chưa có học sinh nào được chấm điểm để gửi.");
      return;
    }
    const campaignData: Array<{ phone: string, message: string }> = [];
    for (const sub of gradedSubs) {
      const student = students.find(s => s.uid === sub.studentId || s.name === sub.studentName);

      // Filter by selected class if specified
      if (selectedFilterClass !== 'ALL') {
        const studentClass = sub.studentClass || (student && student.className) || '';
        if (studentClass !== selectedFilterClass) continue;
      }

      if (target === 'student') {
        const zalo = (student && student.zalo) || sub.studentZalo || null;
        if (!zalo) continue;
        const msg = `Chào em: ${sub.studentName}. Hiện tại đã có kết quả bài tự luận: ${essay.title || 'Tự luận'}. Điểm số của em: ${sub.score} / 10. Em đăng nhập hệ thống để xem chi tiết bài làm nhé!`;
        campaignData.push({ phone: zalo, message: msg });
      } else {
        const parentPhone = student?.parentPhone || null;
        if (!parentPhone) continue;
        const className = student?.className || sub.studentClass || '';
        const classStr = className ? ` - Lớp: ${className}` : '';
        const msg = `Kính gửi Phụ huynh của học sinh: ${sub.studentName}${classStr}: Đã có kết quả bài tự luận "${essay.title || 'Tự luận'}". Điểm số của em đạt: ${sub.score} / 10. Kính báo Phụ huynh theo dõi tình hình học tập của con!`;
        campaignData.push({ phone: parentPhone, message: msg });
      }
    }

    if (campaignData.length === 0) {
      const targetLabel = target === 'student' ? 'học sinh' : 'phụ huynh';
      const classLabel = selectedFilterClass === 'ALL' ? '' : ` của lớp ${selectedFilterClass}`;
      alert(`Không tìm thấy số Zalo/SĐT của ${targetLabel} nào có điểm${classLabel}. Vui lòng kiểm tra lại danh bạ.`);
      return;
    }
    triggerZaloCampaign(campaignData);
  };

  const notifyNotDoneZalo = (target: 'student' | 'parent') => {
    if (!essay || !students || students.length === 0) {
      alert("Danh sách học sinh trống hoặc chưa giao cho lớp nào.");
      return;
    }
    const campaignData: Array<{ phone: string, message: string }> = [];
    const submittedStudentIds = new Set(submissions.map(s => s.studentId).filter(Boolean));
    const submittedStudentNames = new Set(submissions.map(s => s.studentName).filter(Boolean));

    const targetStudents = selectedFilterClass === 'ALL' 
      ? students 
      : students.filter(s => s.className === selectedFilterClass);

    for (const s of targetStudents) {
      const isDone = (s.uid && submittedStudentIds.has(s.uid)) || (s.name && submittedStudentNames.has(s.name));
      if (!isDone) {
        if (target === 'student') {
          if (s.zalo) {
            const msg = `Chào em: ${s.name}. Thầy nhắc em hiện tại có bài tập tự luận chưa nộp: ${essay.title || 'Tự luận'}. Em nhớ đăng nhập vào nộp bài trước hạn nhé!`;
            campaignData.push({ phone: s.zalo, message: msg });
          }
        } else {
          if (s.parentPhone) {
            const classStr = s.className ? ` - Lớp: ${s.className}` : '';
            const msg = `Kính gửi Phụ huynh của học sinh: ${s.name}${classStr}: Hiện tại em vẫn CHƯA NỘP bài tập tự luận "${essay.title || 'Tự luận'}". Kính nhờ Phụ huynh nhắc nhở con vào nộp bài trước hạn!`;
            campaignData.push({ phone: s.parentPhone, message: msg });
          }
        }
      }
    }

    if (campaignData.length === 0) {
      const targetLabel = target === 'student' ? 'học sinh' : 'phụ huynh';
      const classLabel = selectedFilterClass === 'ALL' ? '' : ` thuộc lớp ${selectedFilterClass}`;
      alert(`Tất cả ${targetLabel}${classLabel} đều đã nộp bài hoặc chưa có số điện thoại.`);
      return;
    }
    triggerZaloCampaign(campaignData);
  };

  const executeSendSummaryZalo = () => {
    if (!selectedNotifyClass) return;

    const filteredStudents = students.filter(s => s.className === selectedNotifyClass);

    const doneStudents = filteredStudents.filter(student => 
      submissions.some(sub => sub.studentId === student.uid)
    ).map(student => {
      const sub = submissions.find(s => s.studentId === student.uid);
      return { name: student.name, score: sub?.score, status: sub?.status };
    }).sort((a, b) => {
      const scoreA = typeof a.score === 'number' ? a.score : -1;
      const scoreB = typeof b.score === 'number' ? b.score : -1;
      return scoreB - scoreA;
    });

    const notDoneStudents = filteredStudents.filter(student => 
      !submissions.some(sub => sub.studentId === student.uid)
    );

    let message = `📊 KẾT QUẢ TỰ LUẬN: ${essay.title || 'Bài tập'} (LỚP ${selectedNotifyClass}) 📊\n\n`;

    if (doneStudents.length > 0) {
      message += `✅ ĐÃ NỘP BÀI (${doneStudents.length}):\n`;
      doneStudents.forEach((st, idx) => {
        const scoreStr = st.status === 'graded' && st.score !== undefined && st.score !== null
          ? `${st.score} điểm`
          : 'Đang chấm / Chưa có điểm';
        message += `${idx + 1}. ${st.name}: ${scoreStr}\n`;
      });
      message += `\n`;
    }

    if (notDoneStudents.length > 0) {
      message += `❌ CHƯA NỘP BÀI (${notDoneStudents.length}):\n`;
      notDoneStudents.forEach((st, idx) => {
        message += `${idx + 1}. ${st.name}\n`;
      });
      message += `\n`;
    }

    message += `👉 Link đăng nhập: ${window.location.origin}`;

    navigator.clipboard.writeText(message).catch(err => console.error("Failed to copy", err));
    
    // Find class Zalo link
    const classInfo = classes.find(c => c.name === selectedNotifyClass);
    if (classInfo && classInfo.zaloLink) {
      let webLink = classInfo.zaloLink;
      if (webLink.includes('zalo.me/g/')) {
        webLink = webLink.replace('zalo.me/g/', 'chat.zalo.me/?g=');
      }
      window.open(webLink, '_blank', 'noopener,noreferrer');
    } else {
      window.open('https://chat.zalo.me/', '_blank', 'noopener,noreferrer');
    }
    
    setShowNotifyModal(false);
  };

  if (loading) {
    return (
      <div className="min-h-screen bg-slate-50 flex items-center justify-center">
        <Loader2 className="w-12 h-12 text-indigo-600 animate-spin" />
      </div>
    );
  }

  if (error || !essay) {
    return (
      <div className="min-h-screen bg-slate-50 p-8 flex flex-col items-center justify-center">
        <AlertCircle className="w-16 h-16 text-rose-500 mb-4" />
        <h2 className="text-xl font-bold text-slate-800 mb-2">Đã có lỗi xảy ra</h2>
        <p className="text-slate-600 mb-6">{error || 'Không tìm thấy bài tập'}</p>
        <button onClick={() => navigate(-1)} className="px-6 py-2 bg-indigo-600 text-white rounded-xl font-semibold">
          Quay lại
        </button>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-slate-50 pb-20">
      <div className="bg-white border-b border-slate-200 sticky top-0 z-40">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-3.5">
          <div className="flex flex-col lg:flex-row lg:items-center lg:justify-between gap-4">
            <div className="flex items-center">
              <button onClick={() => navigate(-1)} className="p-2.5 -ml-2.5 mr-3 md:mr-4 text-slate-400 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors">
                <ArrowLeft className="w-6 h-6" />
              </button>
              <div>
                <h1 className="text-xl md:text-2xl font-black text-slate-900 tracking-tight leading-tight">
                  Kết quả Tự luận: {essay.title}
                </h1>
                <p className="text-sm font-medium text-slate-500 mt-1 flex items-center gap-3">
                  <span className="flex items-center">
                    <Users className="w-4 h-4 mr-1.5 text-indigo-500" />
                    Đã nhận <strong className="ml-1 text-indigo-600">{submissions.length}</strong> bài nộp
                  </span>
                  {essay.assignedClasses && essay.assignedClasses.length > 0 && (
                    <span className="text-xs bg-indigo-50 text-indigo-700 px-2 py-0.5 rounded-md font-semibold">
                      Lớp: {essay.assignedClasses.join(', ')}
                    </span>
                  )}
                </p>
              </div>
            </div>

            <div className="flex flex-wrap items-center gap-2">
              {/* Filter by class */}
              {essay.assignedClasses && essay.assignedClasses.length > 0 && (
                <div className="flex items-center bg-slate-50 border border-slate-200 rounded-xl px-3 py-1.5 mr-1">
                  <Filter className="w-4 h-4 text-slate-500 mr-2" />
                  <select
                    value={selectedFilterClass}
                    onChange={(e) => setSelectedFilterClass(e.target.value)}
                    className="bg-transparent text-sm font-semibold text-slate-700 outline-none cursor-pointer"
                    title="Chọn lớp để gửi tin Zalo"
                  >
                    <option value="ALL">Tất cả các lớp</option>
                    {essay.assignedClasses.map((c: string) => (
                      <option key={c} value={c}>Lớp {c}</option>
                    ))}
                  </select>
                </div>
              )}

              {/* Báo điểm Học sinh */}
              <button 
                onClick={() => notifyScoreZalo('student')} 
                className="flex items-center px-3 py-1.5 md:px-3.5 md:py-2 bg-emerald-50 text-emerald-700 border border-emerald-200/60 rounded-xl text-xs md:text-sm font-semibold hover:bg-emerald-100 transition-colors shadow-sm"
                title="Gửi điểm Zalo cho Học sinh"
              >
                <Send className="w-4 h-4 mr-1.5 text-emerald-600" />
                <span>Báo điểm HS</span>
              </button>

              {/* Nhắc chưa làm Học sinh */}
              <button 
                onClick={() => notifyNotDoneZalo('student')} 
                className="flex items-center px-3 py-1.5 md:px-3.5 md:py-2 bg-amber-50 text-amber-700 border border-amber-200/60 rounded-xl text-xs md:text-sm font-semibold hover:bg-amber-100 transition-colors shadow-sm"
                title="Gửi tin Zalo nhắc Học sinh chưa nộp bài"
              >
                <AlertCircle className="w-4 h-4 mr-1.5 text-amber-600" />
                <span>Nhắc chưa nộp HS</span>
              </button>

              {/* Báo điểm Phụ huynh */}
              <button 
                onClick={() => notifyScoreZalo('parent')} 
                className="flex items-center px-3 py-1.5 md:px-3.5 md:py-2 bg-blue-50 text-blue-700 border border-blue-200/60 rounded-xl text-xs md:text-sm font-semibold hover:bg-blue-100 transition-colors shadow-sm"
                title="Gửi tin Zalo báo điểm tự luận cho Phụ huynh"
              >
                <UserCheck className="w-4 h-4 mr-1.5 text-blue-600" />
                <span>Báo điểm Phụ huynh</span>
              </button>

              {/* Nhắc chưa làm Phụ huynh */}
              <button 
                onClick={() => notifyNotDoneZalo('parent')} 
                className="flex items-center px-3 py-1.5 md:px-3.5 md:py-2 bg-orange-50 text-orange-700 border border-orange-200/60 rounded-xl text-xs md:text-sm font-semibold hover:bg-orange-100 transition-colors shadow-sm"
                title="Gửi tin Zalo nhắc Phụ huynh đôn đốc con nộp bài tự luận"
              >
                <Users className="w-4 h-4 mr-1.5 text-orange-600" />
                <span>Nhắc Phụ huynh</span>
              </button>

              {/* Thông báo nhóm Zalo */}
              <button
                onClick={async () => {
                  if (essay.assignedClasses && essay.assignedClasses.length > 0) {
                    setSelectedNotifyClass(selectedFilterClass !== 'ALL' ? selectedFilterClass : essay.assignedClasses[0]);
                  }
                  setShowNotifyModal(true);
                  await loadNotificationData();
                }}
                className="flex items-center px-3 py-1.5 md:px-3.5 md:py-2 bg-indigo-50 text-indigo-700 border border-indigo-200/60 rounded-xl text-xs md:text-sm font-semibold hover:bg-indigo-100 transition-colors shadow-sm"
                title="Gửi bảng tổng hợp điểm vào nhóm Zalo"
              >
                <Send className="w-4 h-4 mr-1.5 text-indigo-600" />
                <span>Báo nhóm</span>
              </button>

              {/* Cấu hình API Key */}
              <button
                onClick={() => {
                  setTempApiKeyInput(customTeacherApiKey);
                  setShowApiKeyModal(true);
                }}
                className={`flex items-center px-3 py-1.5 md:px-3 md:py-2 rounded-xl text-xs md:text-sm font-bold transition-all shadow-sm ${
                  customTeacherApiKey
                    ? 'bg-amber-100 text-amber-900 border border-amber-300 hover:bg-amber-200'
                    : 'bg-slate-100 text-slate-700 hover:bg-slate-200 border border-slate-200/80'
                }`}
                title={customTeacherApiKey ? 'Đang dùng API Key riêng của Thầy/Cô' : 'Cấu hình API Key riêng để tăng hạn ngạch'}
              >
                <Key className="w-4 h-4 mr-1.5 text-amber-600" />
                <span className="hidden sm:inline">{customTeacherApiKey ? 'Key riêng' : 'API Key'}</span>
              </button>

              {/* Nút Làm mới */}
              <button
                onClick={handleManualRefresh}
                disabled={isRefreshing}
                className="flex items-center px-3 py-1.5 md:px-3 md:py-2 bg-slate-100 hover:bg-slate-200 disabled:opacity-50 text-slate-700 rounded-xl font-bold text-xs md:text-sm transition-colors shadow-sm"
                title="Tải lại dữ liệu"
              >
                <RefreshCw className={`w-4 h-4 ${isRefreshing ? 'animate-spin' : ''}`} />
              </button>
            </div>
          </div>
        </div>
      </div>

      <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8 py-8">
        <div className="grid grid-cols-1 lg:grid-cols-12 gap-8">
          
          {/* List of submissions */}
          <div className="lg:col-span-4 space-y-6">
            <div className="flex items-center justify-between">
              <h2 className="text-lg font-bold text-slate-800 flex items-center">
                <Users className="w-5 h-5 mr-2 text-indigo-500" /> Danh sách bài nộp
              </h2>
              {submissions.length > 0 && (
                <div className="flex items-center gap-2">
                  <button
                    onClick={handleRetryErrorsAI}
                    disabled={isGradingAll || isRetryingErrors}
                    className="px-3.5 py-2 bg-rose-600 hover:bg-rose-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center"
                    title="Chấm lại tất cả bài bị báo lỗi của đề bài này"
                  >
                    {isRetryingErrors ? (
                      <><Loader2 className="w-4 h-4 mr-1.5 animate-spin" /> Đang chấm lại {gradingProgress.current}/{gradingProgress.total}</>
                    ) : (
                      <>
                        <RefreshCw className="w-3.5 h-3.5 mr-1.5" />
                        Chấm lại bài lỗi
                      </>
                    )}
                  </button>
                  <button
                    onClick={handleGradeAllAI}
                    disabled={isGradingAll || isRetryingErrors}
                    className="px-4 py-2 bg-emerald-600 hover:bg-emerald-700 disabled:opacity-50 text-white text-xs font-bold rounded-xl transition-all shadow-sm flex items-center"
                  >
                    {isGradingAll ? (
                      <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Đang chấm {Math.min(gradingProgress.current + 1, gradingProgress.total)}/{gradingProgress.total}</>
                    ) : (
                      'Chấm đồng loạt'
                    )}
                  </button>
                </div>
              )}
            </div>

            {/* Live Interactive Batch Progress Card */}
            {(isGradingAll || isRetryingErrors) && (
              <div className="bg-gradient-to-br from-indigo-900 via-indigo-800 to-slate-900 text-white rounded-2xl p-4 shadow-xl border border-indigo-500/30 animate-in fade-in slide-in-from-top-2 duration-300">
                <div className="flex items-center justify-between mb-2">
                  <div className="flex items-center gap-2">
                    <Loader2 className="w-4 h-4 text-emerald-400 animate-spin" />
                    <span className="font-bold text-xs sm:text-sm text-indigo-100">
                      {isRetryingErrors ? 'Đang chấm lại bài lỗi' : 'Tiến trình chấm tự động'}
                    </span>
                  </div>
                  <div className="flex items-center gap-2">
                    <span className="text-xs font-mono font-bold bg-indigo-950/70 px-2 py-0.5 rounded-lg text-emerald-300 border border-indigo-700/50">
                      {gradingProgress.current} / {gradingProgress.total} bài ({gradingProgress.total > 0 ? Math.round((gradingProgress.current / gradingProgress.total) * 100) : 0}%)
                    </span>
                    <button
                      onClick={handleStopBatch}
                      className="text-xs font-bold px-2 py-0.5 bg-rose-600/80 hover:bg-rose-600 text-white rounded-lg transition-colors flex items-center gap-1 shadow-sm"
                      title="Dừng chấm an toàn (không mất kết quả đã chấm)"
                    >
                      <StopCircle className="w-3.5 h-3.5" /> Dừng
                    </button>
                  </div>
                </div>

                {/* Animated Progress Bar */}
                <div className="w-full bg-black/40 rounded-full h-2 mb-2 overflow-hidden border border-white/10">
                  <div 
                    className="bg-gradient-to-r from-emerald-500 to-teal-400 h-2 rounded-full transition-all duration-300 shadow-sm"
                    style={{ width: `${gradingProgress.total > 0 ? Math.max(5, (gradingProgress.current / gradingProgress.total) * 100) : 5}%` }}
                  />
                </div>

                {/* Real-time status text */}
                <div className="space-y-1 text-xs">
                  <div className="flex items-center gap-1.5 text-indigo-200">
                    <span className="text-slate-300 font-semibold">Đang chấm:</span>
                    <span className="text-amber-300 font-bold truncate max-w-[220px]">
                      {activeStudentName || 'Học sinh'}
                    </span>
                  </div>
                  <div className="text-indigo-200/90 flex items-center gap-1.5 leading-snug">
                    <span className="w-2 h-2 rounded-full bg-emerald-400 animate-ping shrink-0 inline-block" />
                    <span className="truncate">{gradingStatusText || 'Đang thực hiện...'}</span>
                  </div>
                </div>
              </div>
            )}
            
            {submissions.length === 0 ? (
              <div className="bg-white rounded-3xl border border-dashed border-slate-200 p-8 text-center">
                <p className="text-slate-500">Chưa có bài nộp.</p>
              </div>
            ) : (
              <div className="space-y-4">
                {(() => {
                  const groupedSubmissions = sortedSubmissions.reduce((acc, sub) => {
                    const student = students.find(s => s.uid === sub.studentId) || { className: 'Khác' };
                    const className = sub.studentClass || student.className || 'Khác';
                    if (!acc[className]) acc[className] = [];
                    acc[className].push(sub);
                    return acc;
                  }, {} as Record<string, any[]>);

                  const sortedClasses = Object.keys(groupedSubmissions).sort((a, b) => {
                    if (a === 'Khác') return 1;
                    if (b === 'Khác') return -1;
                    return a.localeCompare(b);
                  });

                  return sortedClasses.map(className => (
                    <details key={className} className="group bg-white shadow-sm rounded-3xl border border-slate-200/60 [&_summary::-webkit-details-marker]:hidden">
                      <summary className="px-5 py-4 bg-slate-50/50 hover:bg-slate-100/50 border-b border-slate-100 rounded-3xl group-open:rounded-b-none cursor-pointer outline-none flex justify-between items-center transition-colors list-none">
                        <h3 className="text-base font-bold text-slate-800 flex items-center">
                          {className === 'Khác' ? 'Khác' : `Lớp ${className}`}
                          <span className="ml-3 bg-indigo-100 text-indigo-700 py-0.5 px-2.5 rounded-full text-xs font-semibold">
                            {groupedSubmissions[className].length} bài
                          </span>
                        </h3>
                        <svg className="w-5 h-5 text-slate-400 group-open:rotate-180 transition-transform duration-200" fill="none" viewBox="0 0 24 24" stroke="currentColor">
                          <path strokeLinecap="round" strokeLinejoin="round" strokeWidth={2.5} d="M19 9l-7 7-7-7" />
                        </svg>
                      </summary>
                      <div className="overflow-hidden">
                        <ul className="divide-y divide-slate-100">
                          {groupedSubmissions[className].map((sub, idx) => {
                    const student = students.find(s => s.uid === sub.studentId) || { name: sub.studentName };
                    
                    return (
                    <li key={sub.id}>
                      <div 
                        onClick={() => handleSelectSubmission(sub)}
                        className={`w-full cursor-pointer text-left px-5 py-5 hover:bg-slate-50 transition-all ${selectedSubmission?.id === sub.id ? 'bg-indigo-50/50 border-l-4 border-indigo-600' : 'border-l-4 border-transparent'}`}
                      >
                        <div className="flex justify-between items-center">
                          <div>
                            <h3 className="text-sm font-bold text-slate-900">{sub.studentName}</h3>
                            <p className="text-xs text-slate-500 mt-0.5">
                              {new Date(sub.submittedAt).toLocaleDateString()}
                            </p>
                          </div>
                          {sub.status === 'graded' ? (
                            <div className="text-lg font-black text-indigo-600">{sub.score}</div>
                          ) : (sub.status === 'grading' || sub.status === 'grading_in_progress') ? (
                            <div className="text-xs font-bold text-indigo-500 bg-indigo-50 px-2.5 py-1 rounded-lg animate-pulse flex items-center">
                              <Loader2 className="w-3 h-3 mr-1 animate-spin" /> Đang chấm...
                            </div>
                          ) : (sub.status === 'grading_failed' || sub.status === 'key_error') ? (
                            <div className="text-xs font-bold text-rose-500 bg-rose-50 px-2.5 py-1 rounded-lg">Lỗi chấm</div>
                          ) : (
                            <div className="text-xs font-bold text-amber-500 bg-amber-50 px-2 py-1 rounded-lg">Chưa chấm</div>
                          )}
                        </div>
                      </div>
                    </li>
                  )})}
                </ul>
                      </div>
                    </details>
                  ));
                })()}
              </div>
            )}
          </div>

          {/* Submission details & Grading */}
          <div className="lg:col-span-8">
            {selectedSubmission ? (
              <div className="bg-white rounded-3xl border border-slate-200 shadow-sm p-8 relative">
                {loadingFullSubmission && (
                  <div className="absolute inset-0 bg-white/70 backdrop-blur-sm flex flex-col items-center justify-center z-50 rounded-3xl">
                    <Loader2 className="w-10 h-10 text-indigo-600 animate-spin mb-2" />
                    <p className="text-sm font-semibold text-slate-600">Đang tải chi tiết bài làm...</p>
                  </div>
                )}
                <div className="flex justify-between items-start mb-8 pb-8 border-b border-slate-100">
                   <div>
                     <h2 className="text-3xl font-black text-slate-900 tracking-tight">{selectedSubmission.studentName}</h2>
                     <p className="text-slate-500 mt-2 mb-5 font-medium flex items-center space-x-2">
                       <span className="bg-slate-100 px-2.5 py-1 rounded-md text-xs font-bold text-slate-600">Lớp {selectedSubmission.studentClass || 'N/A'}</span>
                       <span className="text-slate-300">•</span>
                       <span className="text-sm">{new Date(selectedSubmission.submittedAt).toLocaleString()}</span>
                     </p>
                     
                     <div className="flex space-x-3">
                        <button
                          onClick={() => handleNotify(selectedSubmission)}
                          className="flex items-center px-4 py-2.5 bg-blue-50 text-blue-700 hover:bg-blue-100 rounded-xl font-bold text-sm transition-colors shadow-sm"
                        >
                          <Send className="w-4 h-4 mr-2" /> Báo điểm
                        </button>
                        <button
                          onClick={() => setSubmissionToDelete(selectedSubmission.id)}
                          className="flex items-center px-4 py-2.5 bg-rose-50 text-rose-700 hover:bg-rose-100 rounded-xl font-bold text-sm transition-colors shadow-sm"
                        >
                          <Trash2 className="w-4 h-4 mr-2" /> Xóa bài
                        </button>
                        {!isEditingGrade && (
                          <button
                            onClick={handleStartEdit}
                            className="flex items-center px-4 py-2.5 bg-amber-50 text-amber-700 hover:bg-amber-100 rounded-xl font-bold text-sm transition-colors shadow-sm animate-in fade-in"
                          >
                            <FileEdit className="w-4 h-4 mr-2" /> Sửa điểm & nhận xét
                          </button>
                        )}
                     </div>
                   </div>
                   {selectedSubmission.status === 'graded' && !isEditingGrade && (
                     <div className="bg-gradient-to-br from-indigo-500 to-indigo-700 text-white rounded-2xl px-8 py-5 text-center shadow-lg shadow-indigo-200 transform hover:scale-105 transition-transform duration-300">
                       <div className="text-5xl font-black tracking-tighter drop-shadow-sm">{selectedSubmission.score}</div>
                       <div className="text-[10px] font-black uppercase tracking-[0.2em] text-indigo-100 mt-1 opacity-90">Điểm số</div>
                     </div>
                   )}
                </div>
                
                {/* Images */}
                {selectedSubmission.images && selectedSubmission.images.length > 0 && (
                  <div className="mb-10">
                    <h3 className="text-lg font-bold text-slate-800 mb-4 flex items-center">
                      <ImageIcon className="w-5 h-5 mr-2 text-indigo-500" /> Bài làm của học sinh
                    </h3>
                    <div className="grid grid-cols-1 md:grid-cols-2 gap-6">
                      {selectedSubmission.images.map((img: string, idx: number) => (
                         <div 
                           key={idx} 
                           className="relative group overflow-hidden rounded-2xl border border-slate-200 shadow-sm hover:shadow-md transition-shadow cursor-pointer"
                           onClick={() => setViewerImageIndex(idx)}
                         >
                           <img src={img} className="w-full object-cover transform group-hover:scale-[1.02] transition-transform duration-500" />
                           <div className="absolute inset-0 bg-black/0 group-hover:bg-black/10 transition-colors flex items-center justify-center">
                             <ZoomIn className="w-8 h-8 text-white opacity-0 group-hover:opacity-100 transition-opacity drop-shadow-md" />
                           </div>
                         </div>
                      ))}
                    </div>
                  </div>
                )}

                {/* AI Feedback / Edit Section */}
                {isEditingGrade ? (
                  <div className="mt-6 p-6 bg-slate-50 border border-slate-200 rounded-2xl space-y-5 animate-in fade-in duration-200">
                    <h3 className="text-lg font-bold text-slate-800 flex items-center">
                      <FileEdit className="w-5 h-5 mr-2 text-amber-500 animate-pulse" /> Chỉnh sửa Điểm & Nhận xét của Giáo viên
                    </h3>
                    
                    <div className="grid grid-cols-1 md:grid-cols-4 gap-6">
                      <div className="md:col-span-1">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Điểm số (0 - 10)</label>
                        <input
                          type="number"
                          step="0.1"
                          min="0"
                          max="10"
                          value={editedScore}
                          onChange={(e) => setEditedScore(e.target.value)}
                          className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl font-extrabold text-indigo-600 text-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent shadow-sm"
                        />
                      </div>
                      <div className="md:col-span-3">
                        <label className="block text-xs font-bold text-slate-500 uppercase tracking-wider mb-2">Nhận xét & Hướng dẫn sửa đổi</label>
                        <textarea
                          rows={12}
                          value={editedFeedback}
                          onChange={(e) => setEditedFeedback(e.target.value)}
                          placeholder="Nhập nhận xét chi tiết cho bài làm tự luận của học sinh tại đây..."
                          className="w-full px-4 py-3 bg-white border border-slate-200 rounded-xl text-slate-700 text-sm focus:outline-none focus:ring-2 focus:ring-indigo-500 focus:border-transparent shadow-sm"
                        />
                      </div>
                    </div>
                    
                    <div className="flex justify-end space-x-3 pt-3 border-t border-slate-200/60">
                      <button
                        type="button"
                        onClick={() => setIsEditingGrade(false)}
                        className="px-5 py-2.5 bg-white border border-slate-200 rounded-xl font-bold text-slate-600 hover:bg-slate-50 transition-colors shadow-sm"
                        disabled={isSavingEdit}
                      >
                        Hủy bỏ
                      </button>
                      <button
                        type="button"
                        onClick={handleSaveEditGrade}
                        disabled={isSavingEdit}
                        className="px-6 py-2.5 bg-indigo-600 text-white rounded-xl font-bold hover:bg-indigo-700 transition-colors shadow-md flex items-center justify-center min-w-[120px]"
                      >
                        {isSavingEdit ? (
                          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Đang lưu...</>
                        ) : (
                          'Lưu thay đổi'
                        )}
                      </button>
                    </div>
                  </div>
                ) : (
                  <div className="pt-2">
                    <div className="flex flex-col md:flex-row md:items-center justify-between mb-6 space-y-4 md:space-y-0">
                      <div>
                        <h3 className="text-xl font-bold text-slate-900 flex items-center">
                          <Sparkles className="w-6 h-6 mr-3 text-amber-500" /> Đánh giá chi tiết từ AI
                        </h3>
                        <p className="text-sm text-slate-500 mt-1">Phân tích từng chi tiết lỗi sai và gợi ý sửa đổi cho bài làm</p>
                      </div>
                      <button 
                        onClick={() => handleGradeAI(selectedSubmission)}
                        disabled={isGrading}
                        className="px-6 py-3 bg-slate-900 text-white rounded-2xl font-bold hover:bg-slate-800 transition-all shadow-md flex items-center justify-center shrink-0 disabled:opacity-50 disabled:cursor-not-allowed"
                      >
                        {isGrading ? (
                          <><Loader2 className="w-4 h-4 mr-2 animate-spin" /> Đang chấm...</>
                        ) : (
                          <>{(selectedSubmission.status === 'graded' || selectedSubmission.status === 'grading' || selectedSubmission.status === 'grading_in_progress') ? 'Chấm lại bài (AI)' : 'Bắt đầu chấm (AI)'}</>
                        )}
                      </button>
                    </div>
                    
                    {selectedSubmission.status === 'grading_failed' || selectedSubmission.status === 'key_error' ? (
                      <div className="p-8 border-2 border-dashed border-rose-200 bg-rose-50/30 rounded-2xl text-center text-rose-700">
                        <AlertCircle className="w-10 h-10 text-rose-500 mx-auto mb-3" />
                        <h4 className="font-bold text-base mb-1 text-rose-900">Lỗi chấm điểm tự động</h4>
                        <p className="text-sm text-slate-600 max-w-md mx-auto mb-4">{selectedSubmission.errorMsg || 'Đã xảy ra lỗi không xác định trong quá trình xử lý.'}</p>
                        <button 
                          onClick={() => handleGradeAI(selectedSubmission)}
                          className="px-4 py-2 bg-rose-600 text-white rounded-xl font-bold text-xs hover:bg-rose-700 transition-colors shadow-sm"
                        >
                          Thử chấm lại
                        </button>
                      </div>
                    ) : selectedSubmission.status === 'grading' || selectedSubmission.status === 'grading_in_progress' ? (
                      <div className="p-10 border-2 border-dashed border-indigo-100 bg-indigo-50/10 rounded-2xl text-center text-indigo-600">
                        <Loader2 className="w-10 h-10 text-indigo-500 animate-spin mx-auto mb-3" />
                        <h4 className="font-bold text-base mb-1">AI đang chấm bài...</h4>
                        <p className="text-xs text-slate-500 max-w-sm mx-auto mb-4">Hệ thống đang tiến hành nhận diện hình ảnh bài làm và phân tích để chấm điểm. Vui lòng đợi trong giây lát.</p>
                        {!isGrading && (
                          <div className="mt-4 pt-4 border-t border-indigo-100/50">
                            <p className="text-xs text-slate-500 mb-3">Lưu ý: Nếu màn hình này bị treo quá lâu (hơn 1 phút), có thể do kết nối bị gián đoạn.</p>
                            <button 
                              onClick={() => handleGradeAI(selectedSubmission)}
                              className="px-4 py-2 bg-indigo-600 hover:bg-indigo-700 text-white rounded-xl font-bold text-xs transition-colors shadow-md"
                            >
                              Bấm vào đây để chấm lại ngay
                            </button>
                          </div>
                        )}
                      </div>
                    ) : selectedSubmission.aiFeedback ? (
                      <div className="bg-slate-50 rounded-2xl p-6 md:p-8 shadow-inner overflow-hidden">
                        <div className="prose prose-slate max-w-none text-slate-700 leading-relaxed">
                          <ReactMarkdown
                            components={{
                              h1: ({node, children, ...props}) => <h1 className="text-xl font-bold text-slate-900 border-b border-slate-200 pb-2 mt-6 mb-3 flex items-center" {...props}>{renderMathChildren(children)}</h1>,
                              h2: ({node, children, ...props}) => <h2 className="text-lg font-bold text-indigo-900 mt-5 mb-2 flex items-center" {...props}>{renderMathChildren(children)}</h2>,
                              h3: ({node, children, ...props}) => <h3 className="text-md font-semibold text-slate-800 mt-4 mb-2" {...props}>{renderMathChildren(children)}</h3>,
                              p: ({node, children, ...props}) => <p className="text-slate-600 mb-4 text-sm md:text-base leading-relaxed" {...props}>{renderMathChildren(children)}</p>,
                              ul: ({node, ...props}) => <ul className="list-disc pl-5 mb-4 space-y-2 text-slate-600 text-sm" {...props} />,
                              ol: ({node, ...props}) => <ol className="list-decimal pl-5 mb-4 space-y-2 text-slate-600 text-sm" {...props} />,
                              li: ({node, children, ...props}) => <li className="pl-1 mb-1 text-slate-600 leading-relaxed" {...props}>{renderMathChildren(children)}</li>,
                              blockquote: ({node, children, ...props}) => (
                                <blockquote className="border-l-4 border-indigo-500 pl-4 italic text-slate-500 my-4 bg-indigo-50/50 py-2 rounded-r-xl" {...props}>{renderMathChildren(children)}</blockquote>
                              ),
                              code: ({node, ...props}) => <code className="bg-indigo-50 text-indigo-600 px-1.5 py-0.5 rounded font-mono text-sm" {...props} />,
                              pre: ({node, ...props}) => <pre className="bg-slate-900 text-slate-100 p-4 rounded-xl overflow-x-auto my-4 text-xs font-mono" {...props} />,
                            }}
                          >
                            {selectedSubmission.aiFeedback}
                          </ReactMarkdown>
                        </div>
                      </div>
                    ) : (
                      <div className="p-10 border-2 border-dashed border-slate-200 rounded-2xl text-center text-slate-500">
                        Chưa có nhận xét AI
                      </div>
                    )}
                  </div>
                )}
              </div>
            ) : (
              <div className="bg-slate-100 rounded-3xl h-full flex items-center justify-center text-slate-500">
                Chọn một bài làm để xem
              </div>
            )}
          </div>
        </div>
      </div>
      
      {/* Delete Submission Confirmation Modal */}
      {submissionToDelete && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-center w-12 h-12 mx-auto bg-red-100 rounded-full mb-4">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-xl font-bold text-center text-gray-900 mb-2">Xác nhận xóa kết quả</h3>
            <p className="text-center text-gray-600 mb-6">
              Bạn có chắc chắn muốn xóa kết quả bài làm này? Sau khi xóa, học sinh sẽ có thể nộp lại bài thi. Hành động này không thể hoàn tác.
            </p>
            <div className="flex justify-center space-x-3">
              <button 
                onClick={() => setSubmissionToDelete(null)} 
                className="px-5 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
                disabled={isDeleting}
              >
                Hủy
              </button>
              <button 
                onClick={handleDeleteSubmission} 
                className="px-5 py-2.5 border border-transparent rounded-xl text-sm font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm"
                disabled={isDeleting}
              >
                {isDeleting ? 'Đang xóa...' : 'Đồng ý xóa'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Grading Confirmation Modal */}
      {showBatchConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-center w-14 h-14 mx-auto bg-emerald-50 text-emerald-600 rounded-full mb-5 shadow-inner">
              <Sparkles className="w-7 h-7" />
            </div>
            <h3 className="text-xl md:text-2xl font-black text-center text-slate-900 mb-3 tracking-tight">Chấm bài đồng loạt</h3>
            <p className="text-center text-sm text-slate-500 leading-relaxed mb-6 font-medium">
              Hệ thống sẽ chấm điểm tự động cho <span className="text-emerald-600 font-extrabold">{submissions.filter(s => s.status !== 'graded').length} bài làm chưa có điểm</span> bằng Thầy Trọng AI. Quá trình này có thể tốn một ít thời gian.
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowBatchConfirm(false)} 
                className="w-1/2 px-4 py-3 border border-slate-200 rounded-2xl text-sm font-bold text-slate-600 bg-white hover:bg-slate-50 transition-all"
              >
                Hủy bỏ
              </button>
              <button 
                onClick={startBatchGrading}
                className="w-1/2 px-4 py-3 bg-emerald-600 hover:bg-emerald-700 text-white rounded-2xl font-black text-sm transition-all shadow-md shadow-emerald-600/15"
              >
                Bắt đầu chấm
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Retry Failed Submissions Confirm Modal */}
      {showRetryConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-center w-14 h-14 mx-auto bg-rose-50 text-rose-600 rounded-full mb-5 shadow-inner">
              <RefreshCw className="w-7 h-7" />
            </div>
            <h3 className="text-xl md:text-2xl font-black text-center text-slate-900 mb-3 tracking-tight">Chấm lại bài bị lỗi</h3>
            <p className="text-center text-sm text-slate-600 leading-relaxed mb-6 font-medium">
              Tìm thấy <span className="text-rose-600 font-extrabold">{submissions.filter(s => s.status === 'grading_failed' || s.status === 'key_error').length} bài bị lỗi</span>. Thầy có muốn hệ thống chấm lại tất cả các bài này không?
            </p>
            <div className="flex gap-3">
              <button 
                onClick={() => setShowRetryConfirm(false)} 
                className="w-1/2 px-4 py-3 border border-slate-200 rounded-2xl text-sm font-bold text-slate-600 bg-white hover:bg-slate-50 transition-all"
              >
                Hủy bỏ
              </button>
              <button 
                onClick={startRetryErrorsGrading}
                className="w-1/2 px-4 py-3 bg-rose-600 hover:bg-rose-700 text-white rounded-2xl font-black text-sm transition-all shadow-md shadow-rose-600/15"
              >
                Bắt đầu chấm lại
              </button>
            </div>
          </div>
        </div>
      )}

      {/* No Failed Submissions Alert Modal */}
      {noFailedAlert && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-center w-14 h-14 mx-auto bg-emerald-50 text-emerald-600 rounded-full mb-5 shadow-inner">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl md:text-2xl font-black text-center text-slate-900 mb-3 tracking-tight">Không có bài lỗi</h3>
            <p className="text-center text-sm text-slate-600 leading-relaxed mb-6 font-medium">
              Tuyệt vời! Không có bài làm nào bị báo lỗi cần chấm lại.
            </p>
            <div className="flex justify-center">
              <button 
                onClick={() => setNoFailedAlert(false)}
                className="w-full sm:w-auto px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-sm transition-all shadow-md"
              >
                Đã hiểu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Retry Grading Success Modal */}
      {showRetrySuccess && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-center w-14 h-14 mx-auto bg-emerald-100 text-emerald-600 rounded-full mb-5 shadow-inner">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl md:text-2xl font-black text-center text-slate-900 mb-3 tracking-tight">Hoàn tất chấm lại</h3>
            <p className="text-center text-sm text-slate-500 leading-relaxed mb-6 font-medium">
              Đã hoàn tất quá trình chấm lại tự động cho các bài làm bị lỗi.
            </p>
            <div className="flex justify-center">
              <button 
                onClick={() => setShowRetrySuccess(false)}
                className="w-full sm:w-auto px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-sm transition-all shadow-md"
              >
                Đồng ý
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Batch Grading Success Modal */}
      {showBatchSuccess && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-center w-14 h-14 mx-auto bg-emerald-100 text-emerald-600 rounded-full mb-5 shadow-inner">
              <CheckCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl md:text-2xl font-black text-center text-slate-900 mb-3 tracking-tight">Chấm xong đồng loạt</h3>
            <p className="text-center text-sm text-slate-500 leading-relaxed mb-6 font-medium">
              Đã hoàn tất quá trình chấm điểm tự động bằng Thầy Trọng AI cho các bài làm chưa chấm.
            </p>
            <div className="flex justify-center">
              <button 
                onClick={() => setShowBatchSuccess(false)}
                className="w-full sm:w-auto px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-sm transition-all shadow-md"
              >
                Đồng ý
              </button>
            </div>
          </div>
        </div>
      )}

      {/* No Ungraded Alert Modal */}
      {noUngradedAlert && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 md:p-8 shadow-2xl border border-slate-100">
            <div className="flex items-center justify-center w-14 h-14 mx-auto bg-indigo-50 text-indigo-600 rounded-full mb-5 shadow-inner">
              <AlertCircle className="w-7 h-7" />
            </div>
            <h3 className="text-xl md:text-2xl font-black text-center text-slate-900 mb-3 tracking-tight">Tất cả đã có điểm</h3>
            <p className="text-center text-sm text-slate-500 leading-relaxed mb-6 font-medium">
              Tất cả các bài giải tự luận của học sinh đều đã được chấm điểm xong. Không còn bài làm nào cần chấm đồng loạt.
            </p>
            <div className="flex justify-center">
              <button 
                onClick={() => setNoUngradedAlert(false)}
                className="w-full sm:w-auto px-8 py-3 bg-slate-900 hover:bg-slate-800 text-white rounded-2xl font-black text-sm transition-all shadow-md"
              >
                Đã hiểu
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Group Notify Modal */}
      {showNotifyModal && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm z-[60] flex items-center justify-center p-4">
          <div className="bg-white rounded-3xl w-full max-w-md p-6 shadow-2xl border border-slate-100 animate-in fade-in duration-200">
            <h3 className="text-xl font-bold text-slate-900 mb-6 flex items-center">
              <Send className="w-5 h-5 mr-2 text-indigo-500" />
              Thông báo nhóm
            </h3>
            {loadingNotificationData ? (
              <div className="flex flex-col items-center py-6">
                <Loader2 className="w-8 h-8 text-indigo-600 animate-spin mb-2" />
                <p className="text-sm text-slate-500">Đang tải danh sách học sinh...</p>
              </div>
            ) : (
              <div className="mb-6">
                <label className="block text-sm font-semibold text-slate-700 mb-2">Chọn lớp cần thông báo</label>
                <select
                  value={selectedNotifyClass}
                  onChange={(e) => setSelectedNotifyClass(e.target.value)}
                  className="w-full border border-slate-200 rounded-2xl px-4 py-3 focus:ring-2 focus:ring-indigo-500 outline-none text-sm font-medium text-slate-700 bg-slate-50"
                >
                  <option value="">-- Chọn lớp --</option>
                  {essay.assignedClasses && essay.assignedClasses.map((cls: string) => (
                    <option key={cls} value={cls}>{cls}</option>
                  ))}
                </select>
              </div>
            )}
            <div className="flex justify-end space-x-3">
              <button
                onClick={() => setShowNotifyModal(false)}
                className="px-5 py-2.5 bg-slate-100 text-slate-700 font-bold rounded-2xl hover:bg-slate-200 transition-colors"
              >
                Hủy
              </button>
              <button
                onClick={executeSendSummaryZalo}
                disabled={!selectedNotifyClass}
                className="px-5 py-2.5 bg-indigo-600 text-white font-bold rounded-2xl hover:bg-indigo-700 transition-colors disabled:opacity-50"
              >
                Gửi Zalo
              </button>
            </div>
          </div>
        </div>
      )}

      {viewerImageIndex !== null && selectedSubmission?.images && (
        <ImageViewer 
          images={selectedSubmission.images} 
          initialIndex={viewerImageIndex} 
          onClose={() => setViewerImageIndex(null)} 
        />
      )}

      {/* Teacher API Key Configuration Modal */}
      {showApiKeyModal && (
        <div className="fixed inset-0 z-50 flex items-center justify-center bg-black/60 backdrop-blur-sm p-4 animate-in fade-in duration-200">
          <div className="bg-white rounded-3xl max-w-md w-full p-6 shadow-2xl border border-slate-100 relative">
            <button 
              onClick={() => setShowApiKeyModal(false)}
              className="absolute top-5 right-5 text-slate-400 hover:text-slate-600 p-1 rounded-full hover:bg-slate-100 transition-colors"
            >
              <X className="w-5 h-5" />
            </button>

            <div className="flex items-center gap-3 mb-4">
              <div className="p-3 bg-amber-100 text-amber-700 rounded-2xl">
                <Key className="w-6 h-6" />
              </div>
              <div>
                <h3 className="text-lg font-bold text-slate-900">Cấu hình API Key Gemini</h3>
                <p className="text-xs text-slate-500">Tùy chọn tăng tốc và nâng cao hạn ngạch chấm bài</p>
              </div>
            </div>

            <div className="space-y-4 text-xs text-slate-600">
              <div className="bg-slate-50 p-3.5 rounded-2xl border border-slate-200 leading-relaxed space-y-1">
                <p className="font-bold text-slate-800">💡 Cơ chế hạn ngạch (Quota):</p>
                <p>• Mặc định hệ thống tự động xoay vòng <strong>10 khóa API</strong> công cộng của trường.</p>
                <p>• Nếu chấm số lượng lớn (60 - 100 bài) liên tục mà không muốn chờ nghỉ hạ nhiệt giữa các phút, Thầy/Cô có thể nhập khóa Gemini API riêng của mình vào đây.</p>
              </div>

              <div>
                <label className="block font-bold text-slate-700 mb-1.5">
                  Gemini API Key cá nhân của Thầy/Cô:
                </label>
                <input
                  type="password"
                  value={tempApiKeyInput}
                  onChange={(e) => setTempApiKeyInput(e.target.value)}
                  placeholder="AIzaSy..."
                  className="w-full px-3.5 py-2.5 border border-slate-200 rounded-xl text-xs font-mono focus:ring-2 focus:ring-amber-500 focus:border-amber-500 outline-none bg-slate-50 focus:bg-white"
                />
                <p className="text-[11px] text-slate-400 mt-1">Khóa chỉ lưu cục bộ trên trình duyệt của Thầy/Cô.</p>
              </div>

              <div className="flex justify-between items-center pt-2">
                {customTeacherApiKey ? (
                  <button
                    onClick={() => {
                      localStorage.removeItem('teacher_gemini_api_key');
                      setCustomTeacherApiKey('');
                      setTempApiKeyInput('');
                      setShowApiKeyModal(false);
                    }}
                    className="text-rose-600 hover:text-rose-700 font-bold hover:underline"
                  >
                    Xóa key riêng
                  </button>
                ) : <span />}
                <div className="flex gap-2">
                  <button
                    onClick={() => setShowApiKeyModal(false)}
                    className="px-4 py-2 border border-slate-200 text-slate-600 hover:bg-slate-50 font-bold rounded-xl transition-colors"
                  >
                    Đóng
                  </button>
                  <button
                    onClick={() => {
                      const trimmed = tempApiKeyInput.trim();
                      if (trimmed) {
                        localStorage.setItem('teacher_gemini_api_key', trimmed);
                        setCustomTeacherApiKey(trimmed);
                      } else {
                        localStorage.removeItem('teacher_gemini_api_key');
                        setCustomTeacherApiKey('');
                      }
                      setShowApiKeyModal(false);
                    }}
                    className="px-4 py-2 bg-amber-600 hover:bg-amber-700 text-white font-bold rounded-xl transition-colors shadow-sm"
                  >
                    Lưu khóa
                  </button>
                </div>
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
