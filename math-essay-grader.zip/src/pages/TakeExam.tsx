import React, { useState, useEffect } from 'react';
import { useParams, useNavigate } from 'react-router-dom';
import { useAuth } from '../lib/AuthContext';
import { db, handleFirestoreError, OperationType, syncExamResultsCover } from '../lib/firebase';
import { doc, getDoc, addDoc, collection, updateDoc, arrayUnion, setDoc } from 'firebase/firestore';
import MathText from '../components/MathText';
import { Clock, AlertCircle, ChevronLeft, CheckCircle, BookOpen } from 'lucide-react';

export default function TakeExam() {
  const { examId } = useParams<{ examId: string }>();
  const { appUser, refreshAppUser } = useAuth();
  const navigate = useNavigate();

  const [exam, setExam] = useState<any>(null);
  const [error, setError] = useState<string | null>(null);
  const [answers, setAnswers] = useState<Record<string, any>>({});
  const [timeLeft, setTimeLeft] = useState<number | null>(null);
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [activeInputId, setActiveInputId] = useState<string | null>(null);
  const [showSubmitConfirm, setShowSubmitConfirm] = useState(false);
  const [showExitConfirm, setShowExitConfirm] = useState(false);
  const [submittedResult, setSubmittedResult] = useState<{score: number, incorrectQuestions: string[]} | null>(null);

  useEffect(() => {
    const fetchExam = async () => {
      if (!examId) return;
      try {
        setError(null);
        // Check sessionStorage cache first to prevent repeated Firestore reads on F5 refresh
        const cachedExam = sessionStorage.getItem('cached_exam_' + examId);
        if (cachedExam) {
          try {
            const data = JSON.parse(cachedExam);
            const now = new Date().getTime();
            const startTime = data.startTime ? new Date(data.startTime).getTime() : null;
            const endTime = data.endTime ? new Date(data.endTime).getTime() : null;
            
            // If cache indicates closed or expired, do not reject immediately!
            // The teacher might have extended the time or opened the exam. Clear stale cache and fetch fresh from Firestore!
            if ((startTime && now < startTime) || (endTime && now > endTime)) {
              sessionStorage.removeItem('cached_exam_' + examId);
            } else {
              setExam(data);
              setTimeLeft(data.duration * 60);
              return;
            }
          } catch (e) {
            sessionStorage.removeItem('cached_exam_' + examId);
          }
        }

        const docRef = doc(db, 'exams', examId);
        const docSnap = await getDoc(docRef);
        if (docSnap.exists()) {
          const data = { id: docSnap.id, ...docSnap.data() } as any;
          
          const now = new Date().getTime();
          const startTime = data.startTime ? new Date(data.startTime).getTime() : null;
          const endTime = data.endTime ? new Date(data.endTime).getTime() : null;
          
          if ((startTime && now < startTime) || (endTime && now > endTime)) {
            alert('Đề thi này hiện không mở.');
            navigate('/student');
            return;
          }

          setExam(data);
          setTimeLeft(data.duration * 60); // convert to seconds
          try {
            sessionStorage.setItem('cached_exam_' + examId, JSON.stringify(data));
          } catch (e) {}
        } else {
          setError('Không tìm thấy đề thi.');
        }
      } catch (err: any) {
        console.error("Error fetching exam:", err);
        if (err.message && err.message.includes('Quota')) {
          setError('Hệ thống đang quá tải (vượt quá giới hạn truy cập miễn phí của Firebase). Vui lòng thử lại sau.');
        } else {
          setError('Đã xảy ra lỗi khi tải đề thi. Vui lòng thử lại.');
        }
      }
    };
    fetchExam();
  }, [examId]);

  // Load draft answers and time left on mount/exam load
  useEffect(() => {
    if (!examId || !exam) return;
    
    // Load answers draft from localStorage
    const savedAnswers = localStorage.getItem(`draft_answers_${examId}`);
    if (savedAnswers) {
      try {
        setAnswers(JSON.parse(savedAnswers));
      } catch (e) {
        console.error("Error parsing saved answers draft", e);
      }
    }

    // Load timeLeft draft from localStorage to prevent cheating or reset
    const savedTimeLeft = localStorage.getItem(`draft_timeleft_${examId}`);
    if (savedTimeLeft) {
      const parsedTime = Number(savedTimeLeft);
      if (!isNaN(parsedTime) && parsedTime > 0) {
        // Only override if the new saved time is less than the current time left
        setTimeLeft(prev => {
          if (prev === null) return parsedTime;
          return Math.min(prev, parsedTime);
        });
      }
    }
  }, [examId, exam]);

  // Save answers draft to localStorage whenever answers change
  useEffect(() => {
    if (!examId || !exam) return;
    const handler = setTimeout(() => {
      if (Object.keys(answers).length > 0) {
        localStorage.setItem(`draft_answers_${examId}`, JSON.stringify(answers));
      }
    }, 1000);
    return () => clearTimeout(handler);
  }, [answers, examId, exam]);

  // Save timeLeft draft to localStorage periodically or on change
  useEffect(() => {
    if (!examId || !exam || timeLeft === null) return;
    localStorage.setItem(`draft_timeleft_${examId}`, timeLeft.toString());
  }, [timeLeft, examId, exam]);

  useEffect(() => {
    if (timeLeft === null || timeLeft <= 0 || submittedResult || isSubmitting) {
      if (timeLeft === 0 && !isSubmitting && !submittedResult) {
        handleSubmit();
      }
      return;
    }
    const timer = setInterval(() => {
      setTimeLeft(prev => (prev !== null ? prev - 1 : null));
    }, 1000);
    return () => clearInterval(timer);
  }, [timeLeft, submittedResult, isSubmitting]);

  const formatTime = (seconds: number) => {
    const m = Math.floor(seconds / 60);
    const s = seconds % 60;
    return `${m.toString().padStart(2, '0')}:${s.toString().padStart(2, '0')}`;
  };

  const handleAnswerChange = (questionId: string, value: any) => {
    setAnswers(prev => ({ ...prev, [questionId]: value }));
  };

  const calculateScore = () => {
    let score = 0;
    let incorrectQuestions: string[] = [];

    exam.questions.forEach((q: any) => {
      const studentAnswer = answers[q.id];
      const correctAnswer = q.correctAnswer;

      if (q.type === 'multiple_choice') {
        if (studentAnswer === correctAnswer) {
          score += 0.25;
        } else {
          incorrectQuestions.push(q.id);
        }
      } else if (q.type === 'true_false') {
        // correctAnswer should be a JSON array like "[true, false, true, false]"
        try {
          const correctArr = JSON.parse(correctAnswer);
          const studentArr = studentAnswer || [];
          let correctParts = 0;
          for (let i = 0; i < 4; i++) {
            if (studentArr[i] === correctArr[i]) correctParts++;
          }
          if (correctParts === 1) score += 0.1;
          else if (correctParts === 2) score += 0.25;
          else if (correctParts === 3) score += 0.5;
          else if (correctParts === 4) score += 1.0;
          
          if (correctParts < 4) incorrectQuestions.push(q.id);
        } catch (e) {
          incorrectQuestions.push(q.id);
        }
      } else if (q.type === 'short_answer') {
        if (studentAnswer && studentAnswer.trim() === correctAnswer?.trim()) {
          score += 0.5;
        } else {
          incorrectQuestions.push(q.id);
        }
      }
    });

    return { score, incorrectQuestions };
  };

  const handleSubmit = async () => {
    if (!exam || !appUser) return;
    setIsSubmitting(true);

    const { score, incorrectQuestions } = calculateScore();

    const submissionData = {
      examId: exam.id,
      studentId: appUser.uid,
      studentName: appUser.name,
      studentClass: appUser.className || '',
      studentZalo: appUser.zalo || null,
      studentFacebook: appUser.facebook || null,
      answers: JSON.stringify(answers),
      score,
      incorrectQuestions,
      submittedAt: new Date().toISOString()
    };

    try {
      const docRef = doc(collection(db, "submissions"));
      await setDoc(docRef, submissionData);
      
      // Update the exam document with a summary of the submission
      // This allows teachers to see who submitted without querying the submissions collection
      const examRef = doc(db, 'exams', exam.id);
      const summaryItem = {
        submissionId: docRef.id,
        studentId: appUser.uid,
        studentName: appUser.name,
        studentClass: appUser.className || '',
        studentZalo: appUser.zalo || null,
        studentFacebook: appUser.facebook || null,
        score,
        incorrectQuestions,
        submittedAt: submissionData.submittedAt
      };
      await setDoc(examRef, { submissionSummary: arrayUnion(summaryItem) }, { merge: true }).catch(e => console.warn("exams cover update failed:", e));

      const examMetaRef = doc(db, 'exams_metadata', exam.id);
      await setDoc(examMetaRef, { submissionSummary: arrayUnion(summaryItem) }, { merge: true }).catch(e => console.warn("exams_metadata update failed:", e));

      // Update the user document so the student can see their result without fetching all exams
      const userRef = doc(db, 'users', appUser.uid);
      await setDoc(userRef, { completedExams: arrayUnion({ examId: exam.id, submissionId: docRef.id, score, submittedAt: submissionData.submittedAt }) }, { merge: true }).catch(e => console.warn("user exams summary update failed:", e));
      const coverRef = doc(db, 'exam_results_cover', exam.id);
      await setDoc(coverRef, {
        submissionSummary: arrayUnion(summaryItem)
      }, { merge: true }).catch(e => console.warn("exam_results_cover update failed:", e));

      setSubmittedResult({ score, incorrectQuestions });
      try {
        localStorage.removeItem(`draft_answers_${exam.id}`);
        localStorage.removeItem(`draft_timeleft_${exam.id}`);
      } catch (e) {}
      await refreshAppUser();
    } catch (error) {
      handleFirestoreError(error, OperationType.CREATE, 'submissions');
    } finally {
      setIsSubmitting(false);
    }
  };

  const handleKeypadClick = (val: string) => {
    if (!activeInputId) return;
    const currentVal = answers[activeInputId] || '';
    if (val === 'DEL') {
      handleAnswerChange(activeInputId, currentVal.slice(0, -1));
    } else if (val === 'CLEAR') {
      handleAnswerChange(activeInputId, '');
    } else {
      handleAnswerChange(activeInputId, currentVal + val);
    }
  };

  if (error) {
    return (
      <div className="flex flex-col h-screen items-center justify-center bg-gray-50 px-4">
        <div className="bg-white p-8 rounded-2xl shadow-lg max-w-md w-full text-center border border-rose-100">
          <div className="w-16 h-16 bg-rose-100 text-rose-600 rounded-full flex items-center justify-center mx-auto mb-4">
            <AlertCircle className="w-8 h-8" />
          </div>
          <h2 className="text-xl font-bold text-gray-900 mb-2">Không thể tải đề thi</h2>
          <p className="text-gray-600 mb-6">{error}</p>
          <button
            onClick={() => navigate('/student')}
            className="w-full bg-indigo-600 text-white py-3 rounded-xl font-semibold hover:bg-indigo-700 transition-colors"
          >
            Quay lại danh sách
          </button>
        </div>
      </div>
    );
  }

  if (!exam) return <div className="flex h-screen items-center justify-center bg-gray-50 text-indigo-600 font-medium text-lg">Đang tải đề thi...</div>;

  if (submittedResult) {
    return (
      <div className="min-h-screen bg-gradient-to-br from-indigo-50 via-white to-blue-50 flex flex-col items-center py-12 px-4">
        <div className="bg-white p-8 rounded-3xl shadow-2xl max-w-3xl w-full text-center animate-in fade-in zoom-in duration-500 border border-gray-100">
          <div className="w-24 h-24 bg-gradient-to-br from-emerald-400 to-teal-500 text-white rounded-full flex items-center justify-center mx-auto mb-6 shadow-lg transform hover:scale-105 transition-transform">
            <CheckCircle className="w-12 h-12" />
          </div>
          <h2 className="text-3xl font-extrabold text-transparent bg-clip-text bg-gradient-to-r from-emerald-600 to-teal-600 mb-2">Nộp bài thành công!</h2>
          <p className="text-gray-500 mb-8 font-medium">Bạn đã hoàn thành bài thi: <span className="font-bold text-gray-800 block mt-1">{exam.title}</span></p>
          
          <div className="bg-gradient-to-br from-gray-50 to-gray-100 border border-gray-200 rounded-2xl p-8 mb-8 shadow-inner">
            <div className="text-sm font-bold text-gray-400 mb-3 uppercase tracking-widest">Điểm của bạn</div>
            <div className="text-6xl font-black text-transparent bg-clip-text bg-gradient-to-r from-indigo-600 to-purple-600 mb-2 drop-shadow-sm">
              {submittedResult.score.toFixed(2)}<span className="text-3xl text-gray-300 font-bold">/10</span>
            </div>
            
            {submittedResult.incorrectQuestions.length > 0 ? (
              <div className="mt-8 text-sm text-rose-600 bg-rose-50/80 border border-rose-100 p-5 rounded-xl text-left shadow-sm">
                <span className="font-bold block mb-2 flex items-center"><AlertCircle className="w-4 h-4 mr-1.5"/> Sai các câu:</span> 
                <div className="flex flex-col gap-2">
                  {submittedResult.incorrectQuestions.map(id => {
                    const idx = exam.questions.findIndex((q:any) => q.id === id);
                    const q = exam.questions[idx];
                    if (!q) return null;
                    
                    let studentAns: any = '';
                    try {
                      studentAns = answers[id];
                    } catch (e) {}
                    
                    let displayStudentAns = String(studentAns || '(Trống)');
                    let displayCorrectAns = String(q.correctAnswer || '(Trống)');
                    
                    if (q.type === 'true_false') {
                      try {
                        const sArr = Array.isArray(studentAns) ? studentAns : [];
                        const cArr = typeof q.correctAnswer === 'string' ? JSON.parse(q.correctAnswer || '[]') : (q.correctAnswer || []);
                        displayStudentAns = sArr.map((v: any) => v === true ? 'Đ' : v === false ? 'S' : '-').join('');
                        displayCorrectAns = cArr.map((v: any) => v === true ? 'Đ' : v === false ? 'S' : '-').join('');
                        if (!displayStudentAns) displayStudentAns = '(Trống)';
                      } catch(e) {}
                    }
                    
                    return (
                      <div key={id} className="bg-white px-3 py-2 rounded-md shadow-sm border border-rose-100">
                        <span className="font-bold">Câu {idx !== -1 ? idx + 1 : '?'}:</span> Bạn chọn <span className="line-through text-rose-400 font-semibold">{displayStudentAns}</span> <span className="text-emerald-600 font-bold ml-1">(Đáp án: {displayCorrectAns})</span>
                      </div>
                    );
                  })}
                </div>
              </div>
            ) : (
              <div className="mt-8 text-sm text-emerald-700 bg-emerald-50/80 border border-emerald-100 p-5 rounded-xl font-bold shadow-sm flex items-center justify-center">
                <CheckCircle className="w-5 h-5 mr-2"/> Hoàn hảo! Bạn không sai câu nào.
              </div>
            )}
          </div>

          <div className="mb-8 text-left">
            <h3 className="text-xl font-bold text-gray-800 mb-4 flex items-center">
              <BookOpen className="w-5 h-5 mr-2 text-indigo-600" />
              Chi tiết bài làm và Lời giải
            </h3>
            <div className="space-y-6">
              {exam.questions.map((question: any, idx: number) => {
                const id = question.id;
                const isQuestionIncorrect = submittedResult.incorrectQuestions?.includes(id);

                  return (
                    <div key={id} className={`bg-white border ${isQuestionIncorrect ? 'border-rose-200' : 'border-emerald-200'} rounded-2xl p-6 shadow-sm`}>
                      <div className={`font-bold text-lg mb-3 flex items-center ${isQuestionIncorrect ? 'text-rose-700' : 'text-emerald-700'}`}>
                        Câu {idx + 1}
                        {!isQuestionIncorrect ? (
                          <span className="ml-2 inline-flex items-center text-sm bg-emerald-100 text-emerald-700 px-2.5 py-0.5 rounded-full"><CheckCircle className="w-4 h-4 mr-1"/> Đúng</span>
                        ) : (
                          <span className="ml-2 inline-flex items-center text-sm bg-rose-100 text-rose-700 px-2.5 py-0.5 rounded-full"><AlertCircle className="w-4 h-4 mr-1"/> Sai</span>
                        )}
                      </div>
                      <div className="text-gray-800 mb-4 font-medium min-w-0 overflow-x-auto">
                        <MathText text={question.content} />
                      </div>
                      
                      {question.type === 'multiple_choice' && question.options && (
                        <div className="space-y-3 mt-4 mb-6">
                          {question.options.map((opt: string, i: number) => {
                            const letter = String.fromCharCode(65 + i);
                            let cleanOpt = opt.replace(new RegExp(`^${letter}[\\.\\:\\)]\\s*|^${letter}\\s+`, 'i'), '').trim();
                            if (!cleanOpt) cleanOpt = opt;
                            
                            const isCorrect = question.correctAnswer === letter;
                            let studentAns = '';
                            try { studentAns = answers[id]; } catch (e) {}
                            const isStudentChoice = studentAns === letter;
                            
                            return (
                              <div key={i} className={`flex items-start p-3 border rounded-xl ${isCorrect ? 'bg-emerald-50 border-emerald-200' : isStudentChoice ? 'bg-rose-50 border-rose-200' : 'bg-gray-50 border-gray-200'}`}>
                                <div className="flex-1 flex items-start">
                                  <span className={`font-semibold mr-2 mt-0.5 ${isCorrect ? 'text-emerald-700' : isStudentChoice ? 'text-rose-700' : 'text-gray-700'}`}>{letter}.</span>
                                  <div className={`flex-1 min-w-0 overflow-x-auto ${isCorrect ? 'text-emerald-800 font-medium' : isStudentChoice ? 'text-rose-800 font-medium' : 'text-gray-800'}`}><MathText text={cleanOpt} /></div>
                                </div>
                                {isCorrect && <CheckCircle className="w-5 h-5 text-emerald-500 ml-2 flex-shrink-0" />}
                                {isStudentChoice && !isCorrect && <AlertCircle className="w-5 h-5 text-rose-500 ml-2 flex-shrink-0" />}
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {question.type === 'true_false' && question.options && (
                        <div className="space-y-3 mt-4 mb-6">
                          {question.options.map((opt: string, i: number) => {
                            const letter = String.fromCharCode(97 + i);
                            let cleanOpt = opt.replace(new RegExp(`^${letter}[\\.\\:\\)]\\s*|^${letter}\\s+`, 'i'), '').trim();
                            if (!cleanOpt) cleanOpt = opt;
                            
                            let correctVal = null;
                            let studentVal = null;
                            try {
                              const cArr = typeof question.correctAnswer === 'string' ? JSON.parse(question.correctAnswer || '[]') : (question.correctAnswer || []);
                              correctVal = cArr[i];
                              const sArr = Array.isArray(answers[id]) ? answers[id] : [];
                              studentVal = sArr[i];
                            } catch(e) {}
                            
                            const isCorrect = studentVal === correctVal;
                            
                            return (
                              <div key={i} className={`flex flex-col sm:flex-row sm:items-center justify-between p-3 border rounded-xl gap-4 ${studentVal !== undefined && studentVal !== null && !isCorrect ? 'bg-rose-50 border-rose-200' : 'bg-gray-50 border-gray-200'}`}>
                                <div className="flex-1 flex items-start">
                                  <span className="font-semibold text-gray-700 mr-3 mt-0.5">{letter}.</span>
                                  <div className="text-gray-800 flex-1 min-w-0 overflow-x-auto"><MathText text={cleanOpt} /></div>
                                </div>
                                <div className="flex flex-col sm:flex-row gap-2 sm:items-center">
                                  {studentVal !== undefined && studentVal !== null && (
                                    <div className={`flex-shrink-0 text-sm px-2 py-1 rounded border ${isCorrect ? 'text-emerald-700 bg-emerald-50 border-emerald-200' : 'text-rose-700 bg-rose-50 border-rose-200'}`}>
                                      Bạn chọn: {studentVal === true ? 'Đúng' : 'Sai'}
                                    </div>
                                  )}
                                  <div className="flex-shrink-0 font-bold text-emerald-600 bg-emerald-50 px-3 py-1 rounded-lg border border-emerald-100">
                                    Đáp án: {correctVal === true ? 'Đúng' : correctVal === false ? 'Sai' : 'Chưa có'}
                                  </div>
                                </div>
                              </div>
                            );
                          })}
                        </div>
                      )}

                      {question.type === 'short_answer' && (
                        <div className="mt-4 mb-6 p-4 border rounded-xl bg-gray-50 border-gray-200">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="flex items-center">
                              <span className="font-semibold text-gray-700 mr-2">Bạn đã nhập:</span>
                              {(() => {
                                  let studentAns = '';
                                  try { studentAns = answers[id] || ''; } catch (e) {}
                                  const isCorrect = studentAns.trim() === (question.correctAnswer || '').trim();
                                  return (
                                    <span className={`font-bold px-3 py-1 rounded-lg border ${isCorrect ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
                                      {studentAns || '(Trống)'}
                                    </span>
                                  );
                              })()}
                            </div>
                            <div className="flex items-center">
                              <span className="font-semibold text-gray-700 mr-2">Đáp án đúng:</span>
                              <span className="font-bold px-3 py-1 rounded-lg border bg-emerald-50 text-emerald-700 border-emerald-200">
                                {question.correctAnswer || '(Chưa có)'}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}

                      {question.type === 'short_answer' && (
                        <div className="mt-4 mb-6 p-4 border rounded-xl bg-gray-50 border-gray-200">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="flex items-center">
                              <span className="font-semibold text-gray-700 mr-2">Bạn đã nhập:</span>
                              {(() => {
                                  let studentAns = '';
                                  try { studentAns = answers[id] || ''; } catch (e) {}
                                  const isCorrect = studentAns.trim() === (question.correctAnswer || '').trim();
                                  return (
                                    <span className={`font-bold px-3 py-1 rounded-lg border ${isCorrect ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
                                      {studentAns || '(Trống)'}
                                    </span>
                                  );
                              })()}
                            </div>
                            <div className="flex items-center">
                              <span className="font-semibold text-gray-700 mr-2">Đáp án đúng:</span>
                              <span className="font-bold px-3 py-1 rounded-lg border bg-emerald-50 text-emerald-700 border-emerald-200">
                                {question.correctAnswer || '(Chưa có)'}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}

                      {question.type === 'short_answer' && (
                        <div className="mt-4 mb-6 p-4 border rounded-xl bg-gray-50 border-gray-200">
                          <div className="flex flex-col sm:flex-row sm:items-center justify-between gap-4">
                            <div className="flex items-center">
                              <span className="font-semibold text-gray-700 mr-2">Bạn đã nhập:</span>
                              {(() => {
                                  let studentAns = '';
                                  try { studentAns = answers[id] || ''; } catch (e) {}
                                  const isCorrect = studentAns.trim() === (question.correctAnswer || '').trim();
                                  return (
                                    <span className={`font-bold px-3 py-1 rounded-lg border ${isCorrect ? 'bg-emerald-50 text-emerald-700 border-emerald-200' : 'bg-rose-50 text-rose-700 border-rose-200'}`}>
                                      {studentAns || '(Trống)'}
                                    </span>
                                  );
                              })()}
                            </div>
                            <div className="flex items-center">
                              <span className="font-semibold text-gray-700 mr-2">Đáp án đúng:</span>
                              <span className="font-bold px-3 py-1 rounded-lg border bg-emerald-50 text-emerald-700 border-emerald-200">
                                {question.correctAnswer || '(Chưa có)'}
                              </span>
                            </div>
                          </div>
                        </div>
                      )}
                      
                      {question.imageUrls && question.imageUrls.length > 0 && (
                        <div className="mb-4 space-y-4">
                          {question.imageUrls.map((url: string, imgIdx: number) => (
                            <img key={imgIdx} src={url} alt={`Câu ${idx + 1} - ảnh ${imgIdx + 1}`} className="max-w-full h-auto rounded-md border border-gray-200" />
                          ))}
                        </div>
                      )}
                      {question.imageUrl && (!question.imageUrls || question.imageUrls.length === 0) && (
                        <div className="mb-4">
                          <img src={question.imageUrl} alt={`Câu ${idx + 1}`} className="max-w-full h-auto rounded-md border border-gray-200" />
                        </div>
                      )}

                      {isQuestionIncorrect && (
                        <div className="bg-indigo-50 border border-indigo-100 rounded-xl p-4 mt-4">
                          <div className="font-semibold text-indigo-800 mb-2">Lời giải chi tiết:</div>
                          <div className="text-gray-700 min-w-0 overflow-x-auto">
                            {question.explanation ? (
                              <MathText text={question.explanation} />
                            ) : (
                              <span className="italic text-gray-500">Chưa có lời giải chi tiết cho câu hỏi này.</span>
                            )}
                          </div>
                        </div>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>

          <button
            onClick={() => navigate('/student')}
            className="w-full bg-gradient-to-r from-indigo-600 to-purple-600 text-white py-4 rounded-2xl font-bold hover:from-indigo-700 hover:to-purple-700 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5 text-lg"
          >
            Quay lại danh sách bài tập
          </button>
        </div>
      </div>
    );
  }

  return (
    <div className="min-h-screen bg-gray-50 pb-24">
      {/* Sticky Header with Timer */}
      <div className="sticky top-0 z-50 bg-white/90 backdrop-blur-lg border-b border-gray-200 px-4 py-3 sm:py-4 flex justify-between items-center shadow-sm">
        <div className="flex items-center">
          <button 
            onClick={() => setShowExitConfirm(true)}
            className="p-2.5 -ml-2 mr-2 text-gray-500 hover:text-indigo-600 hover:bg-indigo-50 rounded-full transition-colors"
            title="Quay lại"
          >
            <ChevronLeft className="w-6 h-6" />
          </button>
          <h1 className="text-lg sm:text-xl font-bold text-gray-800 truncate max-w-[150px] sm:max-w-md">{exam.title}</h1>
        </div>
        <div className={`flex items-center font-mono text-lg sm:text-2xl font-bold px-4 py-2 rounded-2xl shadow-sm border ${timeLeft !== null && timeLeft < 300 ? 'bg-rose-50 text-rose-600 border-rose-200 animate-pulse' : 'bg-indigo-50 text-indigo-700 border-indigo-100'}`}>
          <Clock className="w-5 h-5 sm:w-6 sm:h-6 mr-2" />
          {timeLeft !== null ? formatTime(timeLeft) : '--:--'}
        </div>
        <button
          onClick={() => setShowSubmitConfirm(true)}
          disabled={isSubmitting}
          className="bg-gradient-to-r from-indigo-600 to-purple-600 text-white px-5 sm:px-8 py-2.5 sm:py-3 rounded-xl text-sm sm:text-base font-bold hover:from-indigo-700 hover:to-purple-700 disabled:from-gray-400 disabled:to-gray-500 transition-all shadow-md hover:shadow-lg transform hover:-translate-y-0.5"
        >
          {isSubmitting ? 'Đang nộp...' : 'Nộp bài'}
        </button>
      </div>

      <div className="max-w-4xl mx-auto px-4 py-8">
        <div className="space-y-8">
          {exam.questions.map((q: any, index: number) => (
            <div key={q.id} className="bg-white shadow-sm border border-gray-200 sm:rounded-3xl p-6 md:p-8 transition-all hover:shadow-lg">
              <div className="flex flex-col sm:flex-row sm:items-start mb-8 bg-gradient-to-r from-blue-50 to-indigo-50 border border-blue-100 rounded-2xl p-5 shadow-sm">
                <span className="font-black text-lg mr-4 text-blue-700 whitespace-nowrap bg-white px-4 py-1.5 rounded-xl shadow-sm mb-3 sm:mb-0 border border-blue-100">Câu {index + 1}:</span>
                <div className="text-gray-800 text-lg leading-relaxed mt-1 sm:mt-0 flex-1 font-medium min-w-0 overflow-x-auto">
                  <MathText text={q.content} />
                </div>
              </div>
              
              {q.imageUrls && q.imageUrls.length > 0 && (
                <div className="mb-4 space-y-4">
                  {q.imageUrls.map((url: string, imgIdx: number) => (
                    <img key={imgIdx} src={url} alt={`Câu ${index + 1} - ảnh ${imgIdx + 1}`} className="max-w-full h-auto rounded-md" />
                  ))}
                </div>
              )}
              {/* Fallback for old data */}
              {q.imageUrl && (!q.imageUrls || q.imageUrls.length === 0) && (
                <div className="mb-4">
                  <img src={q.imageUrl} alt={`Câu ${index + 1}`} className="max-w-full h-auto rounded-md" />
                </div>
              )}

              {/* Multiple Choice */}
              {q.type === 'multiple_choice' && q.options && (
                <div className="space-y-3 mt-6">
                  {q.options.map((opt: string, i: number) => {
                    const letter = String.fromCharCode(65 + i);
                    const isSelected = answers[q.id] === letter;
                    let cleanOpt = opt.replace(new RegExp(`^${letter}[\\.\\:\\)]\\s*|^${letter}\\s+`, 'i'), '').trim();
                    if (!cleanOpt) cleanOpt = opt;
                    return (
                      <label key={i} className={`flex items-start p-4 border rounded-xl cursor-pointer transition-all duration-200 ${isSelected ? 'bg-indigo-50 border-indigo-500 ring-1 ring-indigo-500' : 'hover:bg-gray-50 border-gray-200'}`}>
                        <div className="flex items-center h-5 mt-0.5">
                          <input
                            type="radio"
                            name={`q-${q.id}`}
                            value={letter}
                            checked={isSelected}
                            onChange={() => handleAnswerChange(q.id, letter)}
                            className="h-4 w-4 text-indigo-600 focus:ring-indigo-500 border-gray-300"
                          />
                        </div>
                        <div className="ml-3 flex-1 flex items-start">
                          <span className="font-semibold text-gray-700 mr-2 mt-0.5">{letter}.</span>
                          <div className="text-gray-800 flex-1 min-w-0 overflow-x-auto"><MathText text={cleanOpt} /></div>
                        </div>
                      </label>
                    );
                  })}
                </div>
              )}

              {/* True / False */}
              {q.type === 'true_false' && q.options && (
                <div className="space-y-4 mt-6">
                  <p className="text-sm font-medium text-gray-500 uppercase tracking-wider mb-3">Chọn Đúng hoặc Sai cho mỗi phát biểu:</p>
                  <div className="space-y-3">
                    {q.options.map((opt: string, i: number) => {
                      const studentArr = answers[q.id] || [];
                      const currentVal = studentArr[i];
                      const letter = String.fromCharCode(97 + i);
                      let cleanOpt = opt.replace(new RegExp(`^${letter}[\\.\\:\\)]\\s*|^${letter}\\s+`, 'i'), '').trim();
                      if (!cleanOpt) cleanOpt = opt;
                      return (
                        <div key={i} className="flex flex-col sm:flex-row sm:items-center justify-between p-4 border border-gray-200 rounded-xl bg-gray-50/50 hover:bg-gray-50 transition-colors gap-4">
                          <div className="flex-1 flex items-start">
                            <span className="font-semibold text-gray-700 mr-3 mt-0.5">{letter}.</span>
                            <div className="text-gray-800 flex-1 min-w-0 overflow-x-auto"><MathText text={cleanOpt} /></div>
                          </div>
                          <div className="flex space-x-2 sm:flex-shrink-0">
                            <button
                              onClick={() => {
                                const newArr = [...studentArr];
                                newArr[i] = true;
                                handleAnswerChange(q.id, newArr);
                              }}
                              className={`flex-1 sm:flex-none px-6 py-2 rounded-lg text-sm font-medium transition-all ${currentVal === true ? 'bg-green-500 text-white shadow-sm ring-2 ring-green-500 ring-offset-1' : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100'}`}
                            >
                              Đúng
                            </button>
                            <button
                              onClick={() => {
                                const newArr = [...studentArr];
                                newArr[i] = false;
                                handleAnswerChange(q.id, newArr);
                              }}
                              className={`flex-1 sm:flex-none px-6 py-2 rounded-lg text-sm font-medium transition-all ${currentVal === false ? 'bg-red-500 text-white shadow-sm ring-2 ring-red-500 ring-offset-1' : 'bg-white border border-gray-300 text-gray-700 hover:bg-gray-100'}`}
                            >
                              Sai
                            </button>
                          </div>
                        </div>
                      );
                    })}
                  </div>
                </div>
              )}

              {/* Short Answer */}
              {q.type === 'short_answer' && (
                <div className="mt-6">
                  <label className="block text-sm font-medium text-gray-700 mb-3">Nhập đáp án của bạn:</label>
                  <input
                    type="text"
                    readOnly
                    value={answers[q.id] || ''}
                    onClick={() => setActiveInputId(q.id)}
                    placeholder="Nhấp vào đây để sử dụng bàn phím ảo..."
                    className={`block w-full sm:w-2/3 border rounded-xl shadow-sm py-4 px-5 text-lg focus:outline-none focus:ring-2 focus:ring-indigo-500 transition-all cursor-pointer ${activeInputId === q.id ? 'border-indigo-500 ring-2 ring-indigo-500 bg-indigo-50/50' : 'border-gray-300 bg-white hover:bg-gray-50'}`}
                  />
                </div>
              )}
            </div>
          ))}
        </div>
      </div>

      {/* Custom Keypad for Short Answers */}
      {activeInputId && (
        <div className="fixed bottom-0 left-0 right-0 bg-gray-800 p-4 shadow-2xl z-50 animate-in slide-in-from-bottom-10">
          <div className="max-w-md mx-auto">
            <div className="flex justify-between items-center mb-2">
              <span className="text-white text-sm font-medium">Bàn phím nhập liệu</span>
              <button onClick={() => setActiveInputId(null)} className="text-gray-400 hover:text-white text-sm">Đóng</button>
            </div>
            <div className="grid grid-cols-4 gap-2">
              {['7', '8', '9', '+'].map(k => (
                <button key={k} onClick={() => handleKeypadClick(k)} className="bg-gray-700 text-white text-xl font-medium py-3 rounded-md hover:bg-gray-600 active:bg-gray-500">{k}</button>
              ))}
              {['4', '5', '6', '-'].map(k => (
                <button key={k} onClick={() => handleKeypadClick(k)} className="bg-gray-700 text-white text-xl font-medium py-3 rounded-md hover:bg-gray-600 active:bg-gray-500">{k}</button>
              ))}
              {['1', '2', '3', ','].map(k => (
                <button key={k} onClick={() => handleKeypadClick(k)} className="bg-gray-700 text-white text-xl font-medium py-3 rounded-md hover:bg-gray-600 active:bg-gray-500">{k}</button>
              ))}
              <button onClick={() => handleKeypadClick('CLEAR')} className="bg-red-600 text-white text-sm font-medium py-3 rounded-md hover:bg-red-500 active:bg-red-400">Xóa hết</button>
              <button onClick={() => handleKeypadClick('0')} className="bg-gray-700 text-white text-xl font-medium py-3 rounded-md hover:bg-gray-600 active:bg-gray-500">0</button>
              <button onClick={() => handleKeypadClick('.')} className="bg-gray-700 text-white text-xl font-medium py-3 rounded-md hover:bg-gray-600 active:bg-gray-500">.</button>
              <button onClick={() => handleKeypadClick('DEL')} className="bg-yellow-600 text-white text-sm font-medium py-3 rounded-md hover:bg-yellow-500 active:bg-yellow-400">Xóa</button>
            </div>
          </div>
        </div>
      )}
      {/* Submit Confirmation Modal */}
      {showSubmitConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-center w-12 h-12 mx-auto bg-indigo-100 rounded-full mb-4">
              <AlertCircle className="w-6 h-6 text-indigo-600" />
            </div>
            <h3 className="text-xl font-bold text-center text-gray-900 mb-2">Xác nhận nộp bài</h3>
            <p className="text-center text-gray-600 mb-6">
              Bạn có chắc chắn muốn nộp bài thi này không? Sau khi nộp, bạn sẽ không thể thay đổi đáp án.
            </p>
            <div className="flex justify-center space-x-3">
              <button 
                onClick={() => setShowSubmitConfirm(false)} 
                className="px-5 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
                disabled={isSubmitting}
              >
                Quay lại làm bài
              </button>
              <button 
                onClick={() => {
                  setShowSubmitConfirm(false);
                  handleSubmit();
                }} 
                className="px-5 py-2.5 border border-transparent rounded-xl text-sm font-medium text-white bg-indigo-600 hover:bg-indigo-700 transition-colors shadow-sm"
                disabled={isSubmitting}
              >
                {isSubmitting ? 'Đang nộp...' : 'Đồng ý nộp bài'}
              </button>
            </div>
          </div>
        </div>
      )}

      {/* Exit Confirmation Modal */}
      {showExitConfirm && (
        <div className="fixed inset-0 bg-black/60 backdrop-blur-sm flex items-center justify-center p-4 z-[60] animate-in fade-in duration-200">
          <div className="bg-white rounded-2xl max-w-md w-full p-6 shadow-2xl">
            <div className="flex items-center justify-center w-12 h-12 mx-auto bg-red-100 rounded-full mb-4">
              <AlertCircle className="w-6 h-6 text-red-600" />
            </div>
            <h3 className="text-xl font-bold text-center text-gray-900 mb-2">Xác nhận thoát</h3>
            <p className="text-center text-gray-600 mb-6">
              Bạn có chắc chắn muốn thoát khỏi bài thi này? Mọi kết quả làm bài hiện tại sẽ <strong>không được lưu lại</strong>.
            </p>
            <div className="flex justify-center space-x-3">
              <button 
                onClick={() => setShowExitConfirm(false)} 
                className="px-5 py-2.5 border border-gray-300 rounded-xl text-sm font-medium text-gray-700 bg-white hover:bg-gray-50 transition-colors"
              >
                Tiếp tục làm bài
              </button>
              <button 
                onClick={() => navigate('/student')} 
                className="px-5 py-2.5 border border-transparent rounded-xl text-sm font-medium text-white bg-red-600 hover:bg-red-700 transition-colors shadow-sm"
              >
                Thoát bài thi
              </button>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
