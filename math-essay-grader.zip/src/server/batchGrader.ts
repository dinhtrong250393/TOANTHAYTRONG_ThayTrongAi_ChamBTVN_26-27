import { GoogleGenAI } from "@google/genai";
import fs from "fs";
import path from "path";

export interface BatchSubmissionItem {
  id: string;
  studentId: string;
  studentName?: string;
  images?: string[];
  submissionImages?: string[];
  status?: string;
}

export interface BatchGradedResult {
  id: string;
  score: number | null;
  aiFeedback: string;
  status: 'graded' | 'grading_failed';
  gradedAt: number;
  studentId: string;
  studentName?: string;
}

export interface BatchJobState {
  essayId: string;
  total: number;
  completed: number;
  status: 'running' | 'completed' | 'stopped' | 'failed';
  shouldStop: boolean;
  startTime: number;
  finishedTime?: number;
  solutionTextCache?: string;
  results: Record<string, BatchGradedResult>;
  error?: string;
}

// In-memory registry of active and completed batch jobs
const activeJobs = new Map<string, BatchJobState>();

const CHECKPOINT_DIR = path.resolve("/tmp/essay_batch_jobs");
if (!fs.existsSync(CHECKPOINT_DIR)) {
  try {
    fs.mkdirSync(CHECKPOINT_DIR, { recursive: true });
  } catch {
    // Ignore error if directory exists
  }
}

function saveCheckpoint(job: BatchJobState) {
  try {
    const filePath = path.join(CHECKPOINT_DIR, `${job.essayId}.json`);
    fs.writeFileSync(filePath, JSON.stringify(job), "utf8");
  } catch (err) {
    console.error(`[BatchGrader] Error saving checkpoint for ${job.essayId}:`, err);
  }
}

export function getBatchJobStatus(essayId: string): BatchJobState | null {
  if (activeJobs.has(essayId)) {
    return activeJobs.get(essayId)!;
  }
  // Try loading from checkpoint
  try {
    const filePath = path.join(CHECKPOINT_DIR, `${essayId}.json`);
    if (fs.existsSync(filePath)) {
      const data = JSON.parse(fs.readFileSync(filePath, "utf8"));
      activeJobs.set(essayId, data);
      return data;
    }
  } catch {
    // ignore
  }
  return null;
}

export function stopBatchJob(essayId: string): boolean {
  const job = activeJobs.get(essayId);
  if (job && job.status === "running") {
    job.shouldStop = true;
    job.status = "stopped";
    job.finishedTime = Date.now();
    saveCheckpoint(job);
    return true;
  }
  return false;
}

export function clearBatchJob(essayId: string): void {
  activeJobs.delete(essayId);
  try {
    const filePath = path.join(CHECKPOINT_DIR, `${essayId}.json`);
    if (fs.existsSync(filePath)) {
      fs.unlinkSync(filePath);
    }
  } catch {
    // ignore
  }
}

let sharpModule: any = null;
try {
  sharpModule = require("sharp");
} catch {
  sharpModule = null;
}

async function prepareImageContent(imgUrl: string): Promise<any | null> {
  try {
    if (imgUrl.startsWith("data:image/")) {
      const match = imgUrl.match(/^data:(image\/[a-zA-Z+]+);base64,(.+)$/);
      if (match) {
        return {
          inlineData: {
            mimeType: match[1],
            data: match[2].trim()
          }
        };
      }
    }

    const imgRes = await fetch(imgUrl, { signal: AbortSignal.timeout(12000) });
    const arrayBuffer = await imgRes.arrayBuffer();
    let buffer = Buffer.from(arrayBuffer);
    let mimeType = imgRes.headers.get("content-type") || "image/jpeg";

    if (sharpModule) {
      try {
        buffer = await sharpModule(buffer)
          .resize({ width: 1200, withoutEnlargement: true })
          .jpeg({ quality: 75 })
          .toBuffer();
        mimeType = "image/jpeg";
      } catch (sharpErr) {
        console.warn("[BatchGrader] sharp resize failed, using original image:", sharpErr);
      }
    }

    return {
      inlineData: {
        data: buffer.toString("base64"),
        mimeType: mimeType
      }
    };
  } catch (err) {
    console.error("[BatchGrader] Error preparing image:", imgUrl, err);
    return null;
  }
}

export async function startBatchJob(
  essayId: string,
  essay: {
    title?: string;
    questionText?: string;
    solutionText?: string;
    solutionImages?: string[];
  },
  targetSubmissions: BatchSubmissionItem[],
  executeWithKeyRotation: <T>(
    customApiKey: string | undefined,
    fn: (ai: GoogleGenAI, key: string) => Promise<T>
  ) => Promise<T>
): Promise<BatchJobState> {
  const existingJob = activeJobs.get(essayId);
  if (existingJob && existingJob.status === "running") {
    return existingJob;
  }

  const job: BatchJobState = {
    essayId,
    total: targetSubmissions.length,
    completed: 0,
    status: "running",
    shouldStop: false,
    startTime: Date.now(),
    results: {}
  };

  activeJobs.set(essayId, job);
  saveCheckpoint(job);

  // Run in background without awaiting
  (async () => {
    try {
      console.log(`[BatchGrader] Bắt đầu chấm ngầm lô ${targetSubmissions.length} bài cho đề ${essayId}...`);

      // 1. Single-pass OCR Cache for Teacher Solution
      let effectiveSolutionText = essay.solutionText || "";
      if (!effectiveSolutionText && essay.solutionImages && essay.solutionImages.length > 0) {
        console.log(`[BatchGrader] Đang OCR đáp án chuẩn của Giáo viên (chạy 1 lần duy nhất cho toàn bộ lớp)...`);
        const solutionContents: any[] = [
          {
            text: `Bạn là chuyên gia OCR toán học. Hãy đọc và gõ lại CHÍNH XÁC nội dung đáp án/lời giải mẫu của giáo viên trong các hình ảnh sau thành dạng văn bản rõ ràng, giữ nguyên công thức và các bước giải.`
          }
        ];

        for (const solImg of essay.solutionImages) {
          const imgPart = await prepareImageContent(solImg);
          if (imgPart) solutionContents.push(imgPart);
        }

        try {
          const solutionOcrResult = await executeWithKeyRotation(undefined, async (ai) => {
            const resp = await ai.models.generateContent({
              model: "gemini-3.8-flash",
              contents: solutionContents
            });
            return resp.text || "";
          });
          effectiveSolutionText = solutionOcrResult;
          job.solutionTextCache = effectiveSolutionText;
          console.log(`[BatchGrader] OCR đáp án chuẩn hoàn tất (${effectiveSolutionText.length} ký tự). Đã lưu bộ nhớ đệm.`);
        } catch (ocrErr) {
          console.error(`[BatchGrader] OCR đáp án chuẩn gặp lỗi, sử dụng chế độ tự suy luận:`, ocrErr);
          effectiveSolutionText = "Không có văn bản đáp án chuẩn, hãy tự giải và chấm theo tư duy logic toán học chuẩn xác.";
        }
      }

      // 2. Concurrency Pool = 8 workers
      const CONCURRENCY = 8;
      let currentIndex = 0;

      async function worker(workerId: number) {
        while (currentIndex < targetSubmissions.length && !job.shouldStop) {
          const idx = currentIndex++;
          if (idx >= targetSubmissions.length) break;

          const sub = targetSubmissions[idx];
          const studentName = sub.studentName || "Học sinh";

          console.log(`[BatchGrader W#${workerId}] Bắt đầu bài ${idx + 1}/${targetSubmissions.length}: ${studentName} (${sub.id})`);

          let itemResult: BatchGradedResult | null = null;
          let attempt = 0;
          const maxAttempts = 2; // Retry 2 lần theo yêu cầu

          while (attempt < maxAttempts && !itemResult && !job.shouldStop) {
            attempt++;
            try {
              const prompt = `Bạn là một giáo viên chấm thi tự luận.
Dưới đây là bài làm tự luận của học sinh (đính kèm dạng hình ảnh) cùng với Đề bài và Lời giải mẫu (đáp án chuẩn).

Nhiệm vụ của bạn:
1. Đọc và nhận diện chữ viết tay/công thức toán học từ hình ảnh bài làm.
2. Cảnh báo nếu hình ảnh quá mờ hoặc không đọc được.
3. Đối chiếu từng bước giải quyết trong bài làm của học sinh với lời giải chuẩn.
4. NẾU học sinh giải bài toán theo cách KHÁC biệt so với đáp án chuẩn NHƯNG logic vẫn đúng và kết quả đúng, HÃY CÔNG NHẬN CÁCH LÀM ĐÓ và cho điểm tối đa cho phần đó.
5. Đưa ra nhận xét chi tiết, công tâm: chỉ ra điểm đúng, điểm sai, lỗi tư duy hoặc lỗi tính toán (nếu có), và gợi ý cách khắc phục.
6. Bám sát thang điểm: Cộng tổng điểm đạt được một cách chính xác nhất (thang điểm 10, có thể lẻ đến 0.25).

LƯU Ý QUAN TRỌNG VỀ JSON: NẾU TRONG NHẬN XÉT CÓ SỬ DỤNG CÔNG THỨC TOÁN HỌC LATEX (VD: \\infty, \\geq), BẠN PHẢI ESCAPE DẤU BACKSLASH THÀNH 2 DẤU (VD: \\\\infty, \\\\geq) ĐỂ ĐẢM BẢO CHUỖI JSON HỢP LỆ.

TRẢ VỀ KẾT QUẢ DƯỚI DẠNG JSON TUYỆT ĐỐI THEO ĐỊNH DẠNG:
{
  "score": <điểm số từ 0 đến 10, ví dụ 8.5>,
  "aiFeedback": "<nhận xét chi tiết>"
}

--- THÔNG TIN ĐỀ BÀI & LỜI GIẢI ---
Đề bài:
${essay.questionText || "Không có văn bản đề bài"}

Lời giải chuẩn:
${effectiveSolutionText || "Không có lời giải chuẩn, hãy tự giải và đối chiếu logic."}`;

              const contents: any[] = [{ text: prompt }];

              const rawImgs = sub.images || sub.submissionImages || [];
              for (const imgUrl of rawImgs) {
                const imgPart = await prepareImageContent(imgUrl);
                if (imgPart) contents.push(imgPart);
              }

              const gradeData = await executeWithKeyRotation(undefined, async (ai) => {
                const response = await ai.models.generateContent({
                  model: "gemini-3.8-flash",
                  contents: contents,
                  config: {
                    responseMimeType: "application/json"
                  }
                });

                let text = response.text || "";
                const match = text.match(/```(?:json)?\s*([\s\S]*?)```/);
                if (match) text = match[1];
                text = text.trim();
                const sanitizedText = text.replace(/\\([^"\\/bfnrtu])/g, "\\\\$1");
                try {
                  return JSON.parse(sanitizedText);
                } catch {
                  return JSON.parse(text);
                }
              });

              const parsedScore = typeof gradeData.score === "number" ? gradeData.score : parseFloat(gradeData.score) || 0;

              itemResult = {
                id: sub.id,
                score: parsedScore,
                aiFeedback: gradeData.aiFeedback || "Đã chấm điểm.",
                status: "graded",
                gradedAt: Date.now(),
                studentId: sub.studentId,
                studentName
              };
              console.log(`[BatchGrader W#${workerId}] Chấm thành công ${studentName}: ${parsedScore} điểm.`);
            } catch (err: any) {
              console.warn(`[BatchGrader W#${workerId}] Thử lần ${attempt}/${maxAttempts} cho ${studentName} thất bại:`, err.message);
              if (attempt < maxAttempts) {
                await new Promise((res) => setTimeout(res, 1500));
              }
            }
          }

          if (job.shouldStop) break;

          // If failed after maxAttempts, gracefully mark as 'Lỗi chấm'
          if (!itemResult) {
            itemResult = {
              id: sub.id,
              score: null,
              aiFeedback: "Lỗi chấm: Ảnh chụp mờ hoặc không nhận diện được nội dung sau 2 lần thử. Thầy/Cô vui lòng chấm tay.",
              status: "grading_failed",
              gradedAt: Date.now(),
              studentId: sub.studentId,
              studentName
            };
            console.log(`[BatchGrader W#${workerId}] Đã đánh dấu bài ${studentName} là Lỗi chấm (cần chấm tay).`);
          }

          // Staging safely in RAM + file checkpoint
          job.results[sub.id] = itemResult;
          job.completed++;
          saveCheckpoint(job);
        }
      }

      // Launch 8 workers
      const workers = Array.from(
        { length: Math.min(CONCURRENCY, targetSubmissions.length) },
        (_, i) => worker(i + 1)
      );

      await Promise.all(workers);

      job.status = job.shouldStop ? "stopped" : "completed";
      job.finishedTime = Date.now();
      saveCheckpoint(job);

      console.log(`[BatchGrader] Hoàn tất tiến trình chấm cho đề ${essayId}! Đã hoàn thành: ${job.completed}/${job.total}. Trạng thái: ${job.status}`);
    } catch (fatalErr: any) {
      console.error(`[BatchGrader] Lỗi nghiêm trọng trong batch job:`, fatalErr);
      job.status = "failed";
      job.error = fatalErr.message;
      saveCheckpoint(job);
    }
  })();

  return job;
}
